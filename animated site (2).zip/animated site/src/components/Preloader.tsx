import React from 'react';

interface PreloaderProps {
  progress: number;
  isReady: boolean;
}

export const Preloader: React.FC<PreloaderProps> = ({ progress, isReady }) => {
  return (
    <div
      className={`fixed inset-0 z-50 flex flex-col items-center justify-center bg-[#060608] transition-all duration-1000 ease-out ${
        isReady ? 'opacity-0 pointer-events-none scale-105' : 'opacity-100 scale-100'
      }`}
    >
      {/* Ambient background glow */}
      <div className="absolute inset-0 crimson-glow pointer-events-none opacity-40" />

      <div className="relative z-10 flex flex-col items-center max-w-md w-full px-6 text-center">
        {/* Mahindra Twin Peaks / Futuristic Logo */}
        <div className="relative mb-8">
          <div className="w-16 h-16 relative flex items-center justify-center">
            {/* Pulsing red halo */}
            <div className="absolute inset-0 rounded-full bg-[#E31837] blur-xl opacity-40 animate-pulse-slow" />
            <svg
              className="w-12 h-12 text-white relative z-10 drop-shadow-[0_0_15px_rgba(227,24,55,0.8)]"
              viewBox="0 0 100 100"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
            >
              {/* Modern Mahindra Twin Peaks Emblem */}
              <path
                d="M50 12L85 80L68 80L50 44L32 80L15 80L50 12Z"
                fill="url(#logo-grad)"
              />
              <path
                d="M50 56L61 80L39 80L50 56Z"
                fill="#E31837"
              />
              <defs>
                <linearGradient id="logo-grad" x1="50" y1="12" x2="50" y2="80" gradientUnits="userSpaceOnUse">
                  <stop stopColor="#FFFFFF" />
                  <stop offset="0.7" stopColor="#E2E8F0" />
                  <stop offset="1" stopColor="#E31837" />
                </linearGradient>
              </defs>
            </svg>
          </div>
        </div>

        {/* Brand Name */}
        <h1 className="text-3xl sm:text-4xl font-extrabold tracking-[0.3em] font-display text-white mb-3">
          MAHINDRA
        </h1>

        {/* Loading Progress Text */}
        <div className="flex items-center space-x-3 mb-6">
          <span className="text-xs sm:text-sm uppercase tracking-[0.25em] text-zinc-400 font-mono">
            LOADING EXPERIENCE
          </span>
          <span className="text-xs sm:text-sm text-zinc-600 font-mono">—</span>
          <span className="text-sm sm:text-base font-bold font-mono text-[#E31837] drop-shadow-[0_0_10px_rgba(227,24,55,0.6)]">
            {progress}%
          </span>
        </div>

        {/* Minimal Progress Bar */}
        <div className="w-full h-[2px] bg-zinc-800/80 rounded-full overflow-hidden relative mb-4">
          <div
            className="h-full bg-gradient-to-r from-[#880011] via-[#E31837] to-[#FF4D6D] transition-all duration-300 ease-out rounded-full shadow-[0_0_12px_#E31837]"
            style={{ width: `${progress}%` }}
          />
        </div>

        {/* Sub-status messages */}
        <div className="h-5 text-[11px] font-mono tracking-widest text-zinc-500 uppercase transition-all duration-300">
          {progress < 30 && 'INITIALIZING ARCHITECTURE...'}
          {progress >= 30 && progress < 70 && 'BUFFERING CINEMATIC FRAMES...'}
          {progress >= 70 && progress < 100 && 'CALIBRATING RENDERING ENGINE...'}
          {progress === 100 && 'READY TO COMMAND'}
        </div>
      </div>
    </div>
  );
};
