import React from 'react';
import { ArrowDown, Shield, Zap, Cpu, Award, Sparkles, ChevronRight } from 'lucide-react';

interface HeroOverlaysProps {
  scrollProgress: number; // 0 to 1
  onExplore: () => void;
  onBookTestDrive: () => void;
}

export const HeroOverlays: React.FC<HeroOverlaysProps> = ({
  scrollProgress,
  onExplore,
  onBookTestDrive,
}) => {
  // Milestone opacity calculators
  // Intro: 0.0 to 0.18
  const introOpacity = Math.max(0, Math.min(1, (0.16 - scrollProgress) / 0.12));

  // 01 Presence: 0.18 to 0.38
  const p1Active = scrollProgress >= 0.14 && scrollProgress <= 0.38;
  const p1Opacity =
    scrollProgress < 0.14
      ? Math.max(0, (scrollProgress - 0.10) / 0.06)
      : scrollProgress > 0.34
      ? Math.max(0, (0.38 - scrollProgress) / 0.04)
      : 1;

  // 02 Performance: 0.38 to 0.60
  const p2Active = scrollProgress >= 0.38 && scrollProgress <= 0.62;
  const p2Opacity =
    scrollProgress < 0.38
      ? Math.max(0, (scrollProgress - 0.34) / 0.04)
      : scrollProgress > 0.58
      ? Math.max(0, (0.62 - scrollProgress) / 0.04)
      : 1;

  // 03 Technology: 0.62 to 0.82
  const p3Active = scrollProgress >= 0.62 && scrollProgress <= 0.84;
  const p3Opacity =
    scrollProgress < 0.62
      ? Math.max(0, (scrollProgress - 0.58) / 0.04)
      : scrollProgress > 0.80
      ? Math.max(0, (0.84 - scrollProgress) / 0.04)
      : 1;

  // 04 Comfort: 0.84 to 0.99
  const p4Active = scrollProgress >= 0.84;
  const p4Opacity =
    scrollProgress < 0.84
      ? Math.max(0, (scrollProgress - 0.80) / 0.04)
      : 1;

  return (
    <div className="pointer-events-none absolute inset-0 z-20 flex flex-col justify-between p-6 sm:p-10 lg:p-16">
      {/* Top Header Placeholder (Nav takes top) */}
      <div className="h-16" />

      {/* Center Dynamic Area */}
      <div className="relative w-full max-w-7xl mx-auto flex-1 flex flex-col justify-center">
        {/* ========================================================================= */}
        {/* INITIAL HERO INTRO (Scroll 0% - 15%) */}
        {/* ========================================================================= */}
        <div
          className="transition-all duration-300 flex flex-col items-center text-center max-w-4xl mx-auto -mt-6 sm:-mt-10"
          style={{
            opacity: introOpacity,
            transform: `translateY(${(1 - introOpacity) * -30}px) scale(${0.95 + introOpacity * 0.05})`,
            pointerEvents: introOpacity > 0.3 ? 'auto' : 'none',
          }}
        >
          {/* Badge */}
          <div className="inline-flex items-center space-x-2 px-4 py-1.5 rounded-full glass-panel mb-4 sm:mb-6 border border-white/15 shadow-[0_0_25px_rgba(227,24,55,0.3)]">
            <span className="w-2 h-2 rounded-full bg-[#E31837] animate-ping" />
            <span className="text-[10px] sm:text-[11px] font-mono tracking-[0.25em] uppercase text-zinc-200 font-semibold">
              BORN ELECTRIC ARCHITECTURE — BE.05
            </span>
          </div>

          {/* Main Hero Headings */}
          <h2 className="text-4xl sm:text-6xl md:text-7xl font-display font-black tracking-tight text-white mb-2 leading-none drop-shadow-[0_10px_30px_rgba(0,0,0,0.8)]">
            MAHINDRA
          </h2>
          <h3 className="text-xl sm:text-3xl md:text-4xl font-display font-bold tracking-tight text-gradient-red mb-4 drop-shadow-[0_10px_25px_rgba(0,0,0,0.8)]">
            THE NEW GENERATION OF SUV
          </h3>

          <p className="text-xs sm:text-base text-zinc-300 font-light max-w-lg mb-6 sm:mb-8 tracking-wide drop-shadow-[0_4px_12px_rgba(0,0,0,0.9)] bg-black/30 px-4 py-1 rounded-full backdrop-blur-sm border border-white/5">
            Command every road. Experience every moment.
          </p>

          {/* Dual Hero CTAs */}
          <div className="flex flex-col sm:flex-row items-center gap-3 sm:gap-5 w-full sm:w-auto">
            <button
              onClick={onExplore}
              id="hero-explore-btn"
              className="w-full sm:w-auto px-7 py-3.5 sm:px-8 sm:py-4 rounded-full bg-[#E31837] text-white font-bold text-xs sm:text-sm tracking-[0.18em] uppercase shadow-[0_0_30px_rgba(227,24,55,0.6)] hover:bg-[#c0132d] hover:shadow-[0_0_45px_rgba(227,24,55,0.9)] transition-all duration-300 active:scale-95 flex items-center justify-center space-x-2"
            >
              <span>EXPLORE THE SUV</span>
              <ChevronRight className="w-4 h-4" />
            </button>

            <button
              onClick={onBookTestDrive}
              id="hero-test-drive-btn"
              className="w-full sm:w-auto px-7 py-3.5 sm:px-8 sm:py-4 rounded-full glass-panel text-white font-semibold text-xs sm:text-sm tracking-[0.18em] uppercase border border-white/20 hover:border-[#E31837] hover:bg-white/10 transition-all duration-300 active:scale-95 flex items-center justify-center space-x-2"
            >
              <span>BOOK A TEST DRIVE</span>
            </button>
          </div>

          {/* Scroll Down Prompt */}
          <div className="mt-8 sm:mt-12 flex flex-col items-center space-y-1.5 text-zinc-400">
            <span className="text-[10px] font-mono uppercase tracking-[0.3em] text-zinc-400">
              SCROLL TO REVEAL
            </span>
            <div className="w-4 h-7 rounded-full border border-white/20 flex items-start justify-center p-1">
              <div className="w-1 h-1.5 bg-[#E31837] rounded-full animate-bounce" />
            </div>
          </div>
        </div>

        {/* ========================================================================= */}
        {/* MILESTONE 01: PRESENCE (Scroll ~25%) */}
        {/* ========================================================================= */}
        {p1Active && (
          <div
            className="absolute left-0 sm:left-4 max-w-md transition-all duration-300 pointer-events-auto"
            style={{
              opacity: p1Opacity,
              transform: `translateX(${(1 - p1Opacity) * -40}px)`,
            }}
          >
            <div className="glass-card p-6 sm:p-8 rounded-2xl border-l-4 border-l-[#E31837] relative overflow-hidden">
              <div className="absolute top-0 right-0 w-24 h-24 bg-[#E31837]/10 rounded-full blur-2xl" />
              <div className="flex items-center space-x-3 mb-3">
                <span className="text-xs font-mono font-bold tracking-widest text-[#E31837] bg-[#E31837]/10 px-2.5 py-1 rounded">
                  01
                </span>
                <span className="text-xs font-mono uppercase tracking-[0.25em] text-zinc-400">
                  AESTHETIC STANCE
                </span>
              </div>
              <h4 className="text-2xl sm:text-3xl font-display font-bold text-white mb-2 tracking-tight">
                PRESENCE
              </h4>
              <p className="text-sm text-zinc-300 font-normal leading-relaxed mb-4">
                "Designed to command attention."
              </p>
              <div className="text-xs text-zinc-400 space-y-1.5 border-t border-white/10 pt-3">
                <div className="flex justify-between">
                  <span>Silhouette:</span>
                  <span className="text-white font-mono">Aero-Coupe SUV</span>
                </div>
                <div className="flex justify-between">
                  <span>Lighting:</span>
                  <span className="text-white font-mono">Signature C-DRL Matrix</span>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* ========================================================================= */}
        {/* MILESTONE 02: PERFORMANCE (Scroll ~50%) */}
        {/* ========================================================================= */}
        {p2Active && (
          <div
            className="absolute right-0 sm:right-4 max-w-md transition-all duration-300 pointer-events-auto"
            style={{
              opacity: p2Opacity,
              transform: `translateX(${(1 - p2Opacity) * 40}px)`,
            }}
          >
            <div className="glass-card p-6 sm:p-8 rounded-2xl border-r-4 border-r-[#E31837] relative overflow-hidden">
              <div className="absolute top-0 left-0 w-24 h-24 bg-[#E31837]/10 rounded-full blur-2xl" />
              <div className="flex items-center justify-between mb-3">
                <span className="text-xs font-mono font-bold tracking-widest text-[#E31837] bg-[#E31837]/10 px-2.5 py-1 rounded">
                  02
                </span>
                <span className="text-xs font-mono uppercase tracking-[0.25em] text-zinc-400">
                  DUAL-MOTOR DYNAMICS
                </span>
              </div>
              <h4 className="text-2xl sm:text-3xl font-display font-bold text-white mb-2 tracking-tight">
                PERFORMANCE
              </h4>
              <p className="text-sm text-zinc-300 font-normal leading-relaxed mb-4">
                "Engineered for every terrain."
              </p>
              <div className="grid grid-cols-2 gap-2 border-t border-white/10 pt-3">
                <div className="bg-white/5 p-2 rounded-lg">
                  <span className="text-[10px] text-zinc-400 uppercase font-mono block">0–100 KM/H</span>
                  <span className="text-lg font-bold font-mono text-white">3.5 SEC</span>
                </div>
                <div className="bg-white/5 p-2 rounded-lg">
                  <span className="text-[10px] text-zinc-400 uppercase font-mono block">PEAK OUTPUT</span>
                  <span className="text-lg font-bold font-mono text-[#E31837]">335 HP</span>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* ========================================================================= */}
        {/* MILESTONE 03: TECHNOLOGY (Scroll ~75%) */}
        {/* ========================================================================= */}
        {p3Active && (
          <div
            className="absolute left-0 sm:left-4 max-w-md transition-all duration-300 pointer-events-auto"
            style={{
              opacity: p3Opacity,
              transform: `translateX(${(1 - p3Opacity) * -40}px)`,
            }}
          >
            <div className="glass-card p-6 sm:p-8 rounded-2xl border-l-4 border-l-[#38BDF8] relative overflow-hidden">
              <div className="absolute top-0 right-0 w-24 h-24 bg-sky-500/10 rounded-full blur-2xl" />
              <div className="flex items-center space-x-3 mb-3">
                <span className="text-xs font-mono font-bold tracking-widest text-[#38BDF8] bg-sky-500/10 px-2.5 py-1 rounded">
                  03
                </span>
                <span className="text-xs font-mono uppercase tracking-[0.25em] text-zinc-400">
                  AUTONOMOUS INTELLIGENCE
                </span>
              </div>
              <h4 className="text-2xl sm:text-3xl font-display font-bold text-white mb-2 tracking-tight">
                TECHNOLOGY
              </h4>
              <p className="text-sm text-zinc-300 font-normal leading-relaxed mb-4">
                "Intelligence that moves with you."
              </p>
              <div className="text-xs text-zinc-300 space-y-1.5 border-t border-white/10 pt-3 font-mono">
                <div className="flex items-center space-x-2">
                  <div className="w-1.5 h-1.5 rounded-full bg-sky-400" />
                  <span>Level 2+ ADAS 360° Radar & Vision</span>
                </div>
                <div className="flex items-center space-x-2">
                  <div className="w-1.5 h-1.5 rounded-full bg-sky-400" />
                  <span>Dual 12.3" Snapdragon Cinema Cockpit</span>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* ========================================================================= */}
        {/* MILESTONE 04: COMFORT (Scroll ~95%) */}
        {/* ========================================================================= */}
        {p4Active && (
          <div
            className="absolute right-0 sm:right-4 max-w-md transition-all duration-300 pointer-events-auto"
            style={{
              opacity: p4Opacity,
              transform: `translateX(${(1 - p4Opacity) * 40}px)`,
            }}
          >
            <div className="glass-card p-6 sm:p-8 rounded-2xl border-r-4 border-r-[#F59E0B] relative overflow-hidden">
              <div className="absolute top-0 left-0 w-24 h-24 bg-amber-500/10 rounded-full blur-2xl" />
              <div className="flex items-center justify-between mb-3">
                <span className="text-xs font-mono font-bold tracking-widest text-[#F59E0B] bg-amber-500/10 px-2.5 py-1 rounded">
                  04
                </span>
                <span className="text-xs font-mono uppercase tracking-[0.25em] text-zinc-400">
                  REFINED LUXURY
                </span>
              </div>
              <h4 className="text-2xl sm:text-3xl font-display font-bold text-white mb-2 tracking-tight">
                COMFORT
              </h4>
              <p className="text-sm text-zinc-300 font-normal leading-relaxed mb-4">
                "Premium from every angle."
              </p>
              <div className="text-xs text-zinc-300 space-y-1.5 border-t border-white/10 pt-3">
                <div className="flex justify-between">
                  <span>Cabin Atmosphere:</span>
                  <span className="text-amber-300 font-mono">Custom Aura Glow</span>
                </div>
                <div className="flex justify-between">
                  <span>Acoustics:</span>
                  <span className="text-white font-mono">Harman Kardon Spatial Audio</span>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Bottom Progress Telemetry Bar */}
      <div className="w-full max-w-7xl mx-auto flex items-center justify-between pt-4 border-t border-white/10 text-xs font-mono text-zinc-400">
        <div className="flex items-center space-x-3">
          <span className="text-[#E31837] font-bold">MAHINDRA BE.05</span>
          <span className="text-zinc-600">|</span>
          <span className="hidden sm:inline">360° ROTATIONAL REVEAL</span>
        </div>

        {/* Milestone Indicator dots */}
        <div className="flex items-center space-x-2">
          {[
            { label: 'START', active: scrollProgress < 0.15 },
            { label: 'PRESENCE', active: p1Active },
            { label: 'PERFORMANCE', active: p2Active },
            { label: 'TECH', active: p3Active },
            { label: 'COMFORT', active: p4Active },
          ].map((m, idx) => (
            <div
              key={idx}
              className={`flex items-center space-x-1 px-2 py-0.5 rounded text-[10px] uppercase transition-all duration-300 ${
                m.active
                  ? 'bg-[#E31837]/20 text-[#E31837] border border-[#E31837]/40 font-bold'
                  : 'text-zinc-600'
              }`}
            >
              <div
                className={`w-1.5 h-1.5 rounded-full ${
                  m.active ? 'bg-[#E31837] shadow-[0_0_8px_#E31837]' : 'bg-zinc-700'
                }`}
              />
              <span className="hidden md:inline">{m.label}</span>
            </div>
          ))}
        </div>

        {/* Rotation Degree readout */}
        <div className="text-right">
          <span className="text-zinc-500">ANGLE: </span>
          <span className="text-white font-bold">
            {Math.round(scrollProgress * 360)}°
          </span>
        </div>
      </div>
    </div>
  );
};
