import React, { useState } from 'react';
import { ArrowRight, Download, ChevronRight, Sparkles, Check } from 'lucide-react';

interface FinalCTAProps {
  onBookTestDrive: () => void;
  onExploreModels: () => void;
}

export const FinalCTA: React.FC<FinalCTAProps> = ({ onBookTestDrive, onExploreModels }) => {
  const [downloaded, setDownloaded] = useState(false);

  const handleDownloadBrochure = () => {
    setDownloaded(true);
    setTimeout(() => setDownloaded(false), 4000);
  };

  return (
    <section className="relative py-32 sm:py-44 bg-[#060608] text-white overflow-hidden text-center">
      {/* Background High-Impact Spotlight */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[900px] h-[550px] bg-radial from-[#E31837]/25 via-[#990011]/10 to-transparent blur-3xl pointer-events-none" />

      {/* Decorative Lines */}
      <div className="absolute top-0 left-0 right-0 h-[1px] crimson-line" />

      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Brand Tag */}
        <div className="inline-flex items-center space-x-2 px-4 py-1.5 rounded-full glass-badge mb-8 border border-white/10 shadow-[0_0_25px_rgba(227,24,55,0.3)]">
          <span className="w-2 h-2 rounded-full bg-[#E31837] animate-ping" />
          <span className="text-xs font-mono tracking-[0.3em] uppercase text-zinc-300">
            THE NEW ERA OF SUV
          </span>
        </div>

        {/* Cinematic Big Headings */}
        <h2 className="text-3xl sm:text-5xl md:text-6xl font-display font-extrabold tracking-[0.2em] text-zinc-400 mb-2">
          MAHINDRA
        </h2>
        <h3 className="text-4xl sm:text-6xl md:text-7xl lg:text-8xl font-display font-black tracking-tight text-white mb-6 leading-tight">
          READY TO TAKE <br className="hidden sm:inline" />
          <span className="text-gradient-red">THE WHEEL?</span>
        </h3>

        <p className="text-base sm:text-xl text-zinc-300 font-light max-w-2xl mx-auto mb-12 leading-relaxed">
          The future of automotive power is here. Experience the thrilling silence, instant torque, and uncompromising presence of the Mahindra BE series.
        </p>

        {/* Action Buttons */}
        <div className="flex flex-col sm:flex-row items-center justify-center gap-4 sm:gap-6 max-w-xl mx-auto mb-16">
          <button
            onClick={onBookTestDrive}
            id="final-book-test-drive-btn"
            className="w-full sm:w-auto px-10 py-5 rounded-full bg-[#E31837] text-white font-bold text-xs sm:text-sm tracking-[0.2em] uppercase shadow-[0_0_40px_rgba(227,24,55,0.7)] hover:bg-[#c0132d] hover:shadow-[0_0_60px_rgba(227,24,55,1)] transition-all duration-300 active:scale-95 flex items-center justify-center space-x-2 group"
          >
            <span>BOOK A TEST DRIVE</span>
            <ChevronRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
          </button>

          <button
            onClick={onExploreModels}
            id="final-explore-models-btn"
            className="w-full sm:w-auto px-10 py-5 rounded-full glass-panel text-white font-semibold text-xs sm:text-sm tracking-[0.2em] uppercase border border-white/20 hover:border-white/50 hover:bg-white/10 transition-all duration-300 active:scale-95 flex items-center justify-center space-x-2"
          >
            <span>EXPLORE MODELS</span>
          </button>
        </div>

        {/* Brochure Download Card */}
        <div className="inline-flex items-center p-2 sm:p-2.5 rounded-full glass-panel border border-white/15 max-w-md w-full justify-between">
          <div className="flex items-center space-x-3 pl-3 text-left">
            <Download className="w-4 h-4 text-[#E31837]" />
            <div>
              <span className="text-xs font-bold text-white block">BE.05 Official Dossier</span>
              <span className="text-[10px] font-mono text-zinc-400">PDF • 18 MB • Full Technical Specs</span>
            </div>
          </div>
          <button
            onClick={handleDownloadBrochure}
            className="px-4 py-2 rounded-full bg-white/10 hover:bg-white/20 text-xs font-mono text-white transition-colors"
          >
            {downloaded ? (
              <span className="text-emerald-400 flex items-center space-x-1">
                <Check className="w-3.5 h-3.5" />
                <span>DOWNLOADED</span>
              </span>
            ) : (
              'DOWNLOAD'
            )}
          </button>
        </div>
      </div>
    </section>
  );
};
