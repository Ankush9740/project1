import React, { useState } from 'react';
import { Sparkles, Sun, Feather, Maximize, Volume2, ShieldCheck, Heart } from 'lucide-react';
import { AmbientTheme } from '../types';

export const InteriorSection: React.FC = () => {
  const ambientThemes: AmbientTheme[] = [
    {
      id: 'crimson',
      name: 'Blaze Crimson',
      hex: '#E31837',
      glowRgba: 'rgba(227, 24, 55, 0.45)',
      description: 'Dynamic adrenaline mood tuned for spirited night drives and performance focus.',
    },
    {
      id: 'cyan',
      name: 'Cyber Glacier Cyan',
      hex: '#38BDF8',
      glowRgba: 'rgba(56, 189, 248, 0.45)',
      description: 'Cool crystalline serenity with futuristic digital ambiance.',
    },
    {
      id: 'amber',
      name: 'Solar Sunrise Gold',
      hex: '#F59E0B',
      glowRgba: 'rgba(245, 158, 11, 0.45)',
      description: 'Warm, inviting sanctuary reminiscent of golden hour luxury lounges.',
    },
    {
      id: 'violet',
      name: 'Midnight Neon Violet',
      hex: '#A855F7',
      glowRgba: 'rgba(168, 85, 247, 0.45)',
      description: 'Sophisticated deep lounge aura crafted for nocturnal city cruising.',
    },
  ];

  const [activeTheme, setActiveTheme] = useState<AmbientTheme>(ambientThemes[0]);

  return (
    <section id="interior" className="relative py-28 sm:py-36 bg-[#040405] text-white overflow-hidden">
      {/* Dynamic Ambient Cabin Glow */}
      <div
        className="absolute top-1/2 right-1/4 -translate-y-1/2 w-[700px] h-[600px] rounded-full blur-[160px] pointer-events-none transition-all duration-700 opacity-30"
        style={{ backgroundColor: activeTheme.hex }}
      />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16 sm:mb-20">
          <div className="inline-flex items-center space-x-2 px-3.5 py-1 rounded-full glass-badge mb-4 border border-white/10">
            <Sparkles className="w-3.5 h-3.5 text-[#E31837]" />
            <span className="text-[11px] font-mono tracking-[0.25em] uppercase text-zinc-400">
              REFINED SANCTUARY
            </span>
          </div>
          <h2 className="text-3xl sm:text-5xl lg:text-6xl font-display font-extrabold tracking-tight text-white mb-4">
            STEP <span className="text-gradient-red">INSIDE.</span>
          </h2>
          <p className="text-base sm:text-lg text-zinc-300 font-light max-w-xl mx-auto">
            "Where technology meets refined comfort."
          </p>
        </div>

        {/* Panoramic Cockpit Showcase with Live Ambient Light Control */}
        <div className="relative rounded-3xl overflow-hidden glass-card border border-white/15 mb-16 group">
          <div className="relative aspect-[16/9] md:aspect-[21/9] w-full overflow-hidden">
            <img
              src="/images/interior_cockpit.webp"
              alt="Mahindra Luxury Interior Cockpit"
              className="w-full h-full object-cover object-center transform transition-transform duration-1000 group-hover:scale-105"
            />

            {/* Ambient Lighting Overlay dynamically tinted */}
            <div
              className="absolute inset-0 transition-all duration-700 pointer-events-none mix-blend-screen opacity-50"
              style={{
                background: `radial-gradient(ellipse at 50% 70%, ${activeTheme.glowRgba} 0%, transparent 70%)`,
              }}
            />

            {/* Dark gradient for text readability */}
            <div className="absolute inset-0 bg-gradient-to-t from-[#060608] via-transparent to-black/30" />

            {/* Floating Ambient Theme Selector Panel */}
            <div className="absolute bottom-6 left-6 right-6 flex flex-col sm:flex-row sm:items-center justify-between p-4 sm:p-6 rounded-2xl glass-panel border border-white/20 gap-4">
              <div className="flex flex-col">
                <span className="text-[10px] font-mono uppercase tracking-widest text-zinc-400">
                  INTERACTIVE CABIN AMBIANCE
                </span>
                <span className="text-sm sm:text-base font-bold font-display text-white">
                  {activeTheme.name}
                </span>
                <span className="text-xs text-zinc-400 font-light hidden sm:inline">
                  {activeTheme.description}
                </span>
              </div>

              {/* Color Swatches */}
              <div className="flex items-center space-x-3">
                {ambientThemes.map((theme) => {
                  const isSelected = activeTheme.id === theme.id;
                  return (
                    <button
                      key={theme.id}
                      onClick={() => setActiveTheme(theme)}
                      className={`w-9 h-9 rounded-full relative flex items-center justify-center transition-all duration-300 ${
                        isSelected
                          ? 'scale-115 ring-2 ring-white shadow-[0_0_15px_rgba(255,255,255,0.6)]'
                          : 'opacity-70 hover:opacity-100 hover:scale-105'
                      }`}
                      style={{ backgroundColor: theme.hex }}
                      title={theme.name}
                    >
                      {isSelected && <div className="w-2.5 h-2.5 rounded-full bg-white shadow-sm" />}
                    </button>
                  );
                })}
              </div>
            </div>
          </div>
        </div>

        {/* 4 Luxury Cabin Features */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          <div className="glass-card p-6 rounded-2xl border border-white/10">
            <div className="w-10 h-10 rounded-xl bg-white/5 border border-white/10 flex items-center justify-center text-[#E31837] mb-4">
              <Feather className="w-5 h-5" />
            </div>
            <h4 className="text-base font-display font-bold text-white mb-2">
              Zero-Gravity Heated & Cooled Seats
            </h4>
            <p className="text-xs text-zinc-400 font-light leading-relaxed">
              12-way power adjustment with pneumatic lumbar massage and active seat ventilation for fatigue-free long journeys.
            </p>
          </div>

          <div className="glass-card p-6 rounded-2xl border border-white/10">
            <div className="w-10 h-10 rounded-xl bg-white/5 border border-white/10 flex items-center justify-center text-[#E31837] mb-4">
              <Sun className="w-5 h-5" />
            </div>
            <h4 className="text-base font-display font-bold text-white mb-2">
              Panoramic Infinity Skyroof
            </h4>
            <p className="text-xs text-zinc-400 font-light leading-relaxed">
              Electrochromic smart tinting glass blocks 99.8% of UV rays while flooding the cabin with natural daylight.
            </p>
          </div>

          <div className="glass-card p-6 rounded-2xl border border-white/10">
            <div className="w-10 h-10 rounded-xl bg-white/5 border border-white/10 flex items-center justify-center text-[#E31837] mb-4">
              <Sparkles className="w-5 h-5" />
            </div>
            <h4 className="text-base font-display font-bold text-white mb-2">
              Sustainable Vegan Alcantara
            </h4>
            <p className="text-xs text-zinc-400 font-light leading-relaxed">
              Ultra-plush handcrafted upholstery created from 100% recycled marine and botanical polymers.
            </p>
          </div>

          <div className="glass-card p-6 rounded-2xl border border-white/10">
            <div className="w-10 h-10 rounded-xl bg-white/5 border border-white/10 flex items-center justify-center text-[#E31837] mb-4">
              <Volume2 className="w-5 h-5" />
            </div>
            <h4 className="text-base font-display font-bold text-white mb-2">
              Acoustic Double-Glazing
            </h4>
            <p className="text-xs text-zinc-400 font-light leading-relaxed">
              Acoustic laminated glass and active road noise cancellation create an ultra-silent sanctuary at any speed.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};
