import React, { useState } from 'react';
import { Zap, Gauge, BatteryCharging, Compass, Activity, Shield, Flame, Radio } from 'lucide-react';
import { DriveMode } from '../types';

export const PerformanceSection: React.FC = () => {
  const driveModes: DriveMode[] = [
    {
      id: 'zip',
      name: 'ZIP',
      badge: 'URBAN CRUISE',
      tagline: 'Smooth, effortless city glide with maximum regenerative braking.',
      description: 'Optimized for inner-city commuting, feather-light steering response, and max energy recuperation.',
      accentColor: '#38BDF8',
      glowColor: 'rgba(56, 189, 248, 0.3)',
      stats: {
        power: '180 HP',
        suspension: 'Ultra Comfort',
        steering: 'Light & Agile',
        efficiency: '96% Max Regen',
      },
    },
    {
      id: 'zap',
      name: 'ZAP',
      badge: 'HIGHWAY TOURER',
      tagline: 'Balanced dynamic power delivery for effortless long-distance cruising.',
      description: 'Dual motors engage seamlessly for instant overtaking power with aerodynamic suspension lowering.',
      accentColor: '#10B981',
      glowColor: 'rgba(16, 185, 129, 0.3)',
      stats: {
        power: '260 HP',
        suspension: 'Balanced Dynamic',
        steering: 'Progressive Assist',
        efficiency: '88% Highway Aero',
      },
    },
    {
      id: 'zoom',
      name: 'ZOOM',
      badge: 'MAX PERFORMANCE',
      tagline: 'Unleash full dual-motor 335 HP torque with track-tuned launch control.',
      description: 'Instant 0–100 km/h in 3.5 seconds, firm damper valving, and authentic acoustic cockpit soundscapes.',
      accentColor: '#E31837',
      glowColor: 'rgba(227, 24, 55, 0.4)',
      stats: {
        power: '335 HP (535 Nm)',
        suspension: 'Track Stiffened',
        steering: 'Direct Razor Sharp',
        efficiency: '100% Boost Output',
      },
    },
    {
      id: 'offroad',
      name: 'OFF-ROAD',
      badge: 'ALL-TERRAIN 4X4',
      tagline: 'Electronic AWD terrain response for mud, sand, snow, and boulders.',
      description: 'Suspension lifts 35mm, torque splits 50:50, and hill-descent assist ensures total command.',
      accentColor: '#F59E0B',
      glowColor: 'rgba(245, 158, 11, 0.35)',
      stats: {
        power: 'AWD 50:50 Lock',
        suspension: '+35mm Lifted',
        steering: 'High Feedback',
        efficiency: 'Terrain Crawl Mode',
      },
    },
  ];

  const [selectedMode, setSelectedMode] = useState<DriveMode>(driveModes[2]); // Default Zoom mode

  return (
    <section id="performance" className="relative py-28 sm:py-36 bg-[#040405] text-white overflow-hidden">
      {/* Dynamic Ambient Background Glow matched to active Drive Mode */}
      <div
        className="absolute top-1/3 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[500px] rounded-full blur-[140px] transition-all duration-700 pointer-events-none opacity-25"
        style={{ backgroundColor: selectedMode.accentColor }}
      />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-20">
          <div className="inline-flex items-center space-x-2 px-3.5 py-1 rounded-full glass-badge mb-4 border border-white/10">
            <Zap className="w-3.5 h-3.5 text-[#E31837]" />
            <span className="text-[11px] font-mono tracking-[0.25em] uppercase text-zinc-400">
              ELECTRIFIED POWERTRAIN DYNAMICS
            </span>
          </div>
          <h2 className="text-3xl sm:text-5xl lg:text-6xl font-display font-extrabold tracking-tight text-white mb-4">
            BUILT FOR <span className="text-gradient-red">EVERY ROAD.</span>
          </h2>
          <p className="text-sm sm:text-base text-zinc-400 font-light max-w-xl mx-auto">
            Engineered with INGLO architecture, delivering instantaneous electric response, razor-sharp torque vectoring, and all-weather confidence.
          </p>
        </div>

        {/* Large Numbers Metrics Grid */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6 mb-20">
          {/* Stat 1 */}
          <div className="glass-card p-6 sm:p-8 rounded-2xl border border-white/10 text-center relative overflow-hidden group">
            <div className="absolute top-0 left-0 right-0 h-[2px] bg-gradient-to-r from-transparent via-[#E31837] to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
            <span className="text-[11px] font-mono uppercase tracking-widest text-zinc-400 block mb-2">
              0 – 100 KM/H
            </span>
            <div className="text-3xl sm:text-5xl lg:text-6xl font-extrabold font-display text-white tracking-tight mb-2">
              3.5<span className="text-xl sm:text-2xl text-[#E31837] font-mono">s</span>
            </div>
            <span className="text-xs text-zinc-400 font-light">
              Dual-motor launch control
            </span>
          </div>

          {/* Stat 2 */}
          <div className="glass-card p-6 sm:p-8 rounded-2xl border border-white/10 text-center relative overflow-hidden group">
            <div className="absolute top-0 left-0 right-0 h-[2px] bg-gradient-to-r from-transparent via-[#E31837] to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
            <span className="text-[11px] font-mono uppercase tracking-widest text-zinc-400 block mb-2">
              MAX RANGE (WLTP)
            </span>
            <div className="text-3xl sm:text-5xl lg:text-6xl font-extrabold font-display text-white tracking-tight mb-2">
              550<span className="text-xl sm:text-2xl text-[#E31837] font-mono">km</span>
            </div>
            <span className="text-xs text-zinc-400 font-light">
              79 kWh LFP Blade Battery
            </span>
          </div>

          {/* Stat 3 */}
          <div className="glass-card p-6 sm:p-8 rounded-2xl border border-white/10 text-center relative overflow-hidden group">
            <div className="absolute top-0 left-0 right-0 h-[2px] bg-gradient-to-r from-transparent via-[#E31837] to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
            <span className="text-[11px] font-mono uppercase tracking-widest text-zinc-400 block mb-2">
              PEAK POWER
            </span>
            <div className="text-3xl sm:text-5xl lg:text-6xl font-extrabold font-display text-white tracking-tight mb-2">
              335<span className="text-xl sm:text-2xl text-[#E31837] font-mono">hp</span>
            </div>
            <span className="text-xs text-zinc-400 font-light">
              535 Nm Instant Torque
            </span>
          </div>

          {/* Stat 4 */}
          <div className="glass-card p-6 sm:p-8 rounded-2xl border border-white/10 text-center relative overflow-hidden group">
            <div className="absolute top-0 left-0 right-0 h-[2px] bg-gradient-to-r from-transparent via-[#E31837] to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
            <span className="text-[11px] font-mono uppercase tracking-widest text-zinc-400 block mb-2">
              ULTRA-FAST DC CHARGE
            </span>
            <div className="text-3xl sm:text-5xl lg:text-6xl font-extrabold font-display text-white tracking-tight mb-2">
              20<span className="text-xl sm:text-2xl text-[#E31837] font-mono">min</span>
            </div>
            <span className="text-xs text-zinc-400 font-light">
              20% to 80% at 175 kW
            </span>
          </div>
        </div>

        {/* Interactive Drive Mode Experience Console */}
        <div className="glass-panel p-6 sm:p-10 rounded-3xl border border-white/15 relative overflow-hidden">
          {/* Header Bar */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-6 mb-8 border-b border-white/10 gap-4">
            <div>
              <span className="text-xs font-mono uppercase tracking-widest text-zinc-400 block">
                INGLO DRIVE MODE SELECTOR
              </span>
              <h3 className="text-xl sm:text-2xl font-display font-bold text-white">
                Customize Your Driving Dynamics
              </h3>
            </div>
            <div className="flex items-center space-x-2">
              <span className="w-2 h-2 rounded-full animate-ping" style={{ backgroundColor: selectedMode.accentColor }} />
              <span className="text-xs font-mono tracking-wider uppercase text-zinc-300">
                ACTIVE PROFILE: {selectedMode.name}
              </span>
            </div>
          </div>

          {/* Mode Selector Buttons */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-8">
            {driveModes.map((mode) => {
              const isSelected = selectedMode.id === mode.id;
              return (
                <button
                  key={mode.id}
                  onClick={() => setSelectedMode(mode)}
                  className={`p-4 rounded-xl text-left transition-all duration-300 border relative overflow-hidden ${
                    isSelected
                      ? 'bg-white/10 border-white/40 shadow-[0_0_20px_rgba(255,255,255,0.1)]'
                      : 'bg-white/[0.02] border-white/5 hover:border-white/20'
                  }`}
                >
                  {isSelected && (
                    <div
                      className="absolute top-0 left-0 right-0 h-1"
                      style={{ backgroundColor: mode.accentColor }}
                    />
                  )}
                  <div className="flex items-center justify-between mb-2">
                    <span
                      className="text-lg font-display font-black tracking-wider"
                      style={{ color: isSelected ? mode.accentColor : '#FFFFFF' }}
                    >
                      {mode.name}
                    </span>
                    <span className="text-[10px] font-mono text-zinc-400 uppercase">
                      {mode.badge}
                    </span>
                  </div>
                  <p className="text-xs text-zinc-400 line-clamp-1 font-light">
                    {mode.tagline}
                  </p>
                </button>
              );
            })}
          </div>

          {/* Live Telemetry Display for Selected Mode */}
          <div className="grid grid-cols-1 md:grid-cols-12 gap-8 items-center bg-black/40 p-6 rounded-2xl border border-white/5">
            {/* Chassis Platform Graphic */}
            <div className="md:col-span-6 relative rounded-xl overflow-hidden aspect-[16/9] border border-white/10">
              <img
                src="/images/chassis_battery.webp"
                alt="Chassis Platform"
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent" />
              <div className="absolute bottom-3 left-3 right-3 flex items-center justify-between text-xs font-mono text-zinc-300">
                <span>INGLO SKATEBOARD PLATFORM</span>
                <span style={{ color: selectedMode.accentColor }}>CALIBRATED</span>
              </div>
            </div>

            {/* Spec Matrix */}
            <div className="md:col-span-6 flex flex-col justify-between space-y-4">
              <div className="space-y-1">
                <span className="text-xs font-mono uppercase tracking-widest" style={{ color: selectedMode.accentColor }}>
                  {selectedMode.badge}
                </span>
                <h4 className="text-2xl font-display font-bold text-white">
                  {selectedMode.name} Mode Engaged
                </h4>
                <p className="text-xs sm:text-sm text-zinc-300 font-light leading-relaxed">
                  {selectedMode.description}
                </p>
              </div>

              <div className="grid grid-cols-2 gap-3 pt-4 border-t border-white/10">
                <div className="bg-white/5 p-3 rounded-lg">
                  <span className="text-[10px] font-mono text-zinc-400 block uppercase">PEAK POWER</span>
                  <span className="text-sm font-mono font-bold text-white">{selectedMode.stats.power}</span>
                </div>
                <div className="bg-white/5 p-3 rounded-lg">
                  <span className="text-[10px] font-mono text-zinc-400 block uppercase">DAMPER TUNING</span>
                  <span className="text-sm font-mono font-bold text-white">{selectedMode.stats.suspension}</span>
                </div>
                <div className="bg-white/5 p-3 rounded-lg">
                  <span className="text-[10px] font-mono text-zinc-400 block uppercase">STEERING MAP</span>
                  <span className="text-sm font-mono font-bold text-white">{selectedMode.stats.steering}</span>
                </div>
                <div className="bg-white/5 p-3 rounded-lg">
                  <span className="text-[10px] font-mono text-zinc-400 block uppercase">ENERGY PROFILE</span>
                  <span className="text-sm font-mono font-bold text-white">{selectedMode.stats.efficiency}</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
