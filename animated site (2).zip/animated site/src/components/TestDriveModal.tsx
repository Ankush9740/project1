import React, { useState } from 'react';
import { X, CheckCircle, Calendar, Clock, MapPin, User, Mail, Phone, Car, Sparkles, ChevronRight } from 'lucide-react';
import confetti from 'canvas-confetti';
import { TestDriveFormData } from '../types';

interface TestDriveModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const TestDriveModal: React.FC<TestDriveModalProps> = ({ isOpen, onClose }) => {
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [formData, setFormData] = useState<TestDriveFormData>({
    fullName: '',
    email: '',
    phone: '',
    city: 'Mumbai',
    dealership: 'Mahindra Signature Studio — Worli',
    model: 'Mahindra BE.05 Electric Coupe',
    preferredDate: '',
    timeSlot: '11:00 AM – 01:00 PM',
  });

  const citiesWithDealerships: Record<string, string[]> = {
    Mumbai: [
      'Mahindra Signature Studio — Worli',
      'Mahindra Prime Hub — Andheri West',
      'Mahindra EV Hub — Navi Mumbai',
    ],
    'Delhi NCR': [
      'Mahindra Flagship Experience — Connaught Place',
      'Mahindra EV Studio — Cyber City Gurugram',
      'Mahindra Prime — Noida Sector 18',
    ],
    Bengaluru: [
      'Mahindra Experience Center — Indiranagar',
      'Mahindra Tech Park Studio — Whitefield',
      'Mahindra EV Hub — Koramangala',
    ],
    Hyderabad: [
      'Mahindra Signature Studio — Jubilee Hills',
      'Mahindra EV Galleria — Hitec City',
    ],
    Chennai: [
      'Mahindra Prime Studio — Anna Nagar',
      'Mahindra EV Hub — OMR IT Corridor',
    ],
    Pune: [
      'Mahindra Signature Lounge — Koregaon Park',
      'Mahindra Auto Hub — Baner',
    ],
  };

  const handleCityChange = (city: string) => {
    const defaultDealership = citiesWithDealerships[city]?.[0] || '';
    setFormData({ ...formData, city, dealership: defaultDealership });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitted(true);

    // Trigger celebratory luxury confetti
    confetti({
      particleCount: 80,
      spread: 70,
      origin: { y: 0.6 },
      colors: ['#E31837', '#FFFFFF', '#38BDF8', '#F59E0B'],
    });
  };

  const handleReset = () => {
    setIsSubmitted(false);
    onClose();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 overflow-y-auto bg-black/80 backdrop-blur-xl animate-fade-in">
      {/* Modal Container */}
      <div className="relative w-full max-w-2xl bg-[#0a0a0e] border border-white/15 rounded-3xl p-6 sm:p-10 shadow-[0_25px_70px_rgba(0,0,0,0.9)] overflow-hidden">
        {/* Background glow */}
        <div className="absolute top-0 right-0 w-80 h-80 bg-[#E31837]/15 rounded-full blur-3xl pointer-events-none" />

        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-6 right-6 p-2 rounded-full bg-white/5 border border-white/10 text-zinc-400 hover:text-white hover:bg-white/10 transition-all z-10"
        >
          <X className="w-5 h-5" />
        </button>

        {!isSubmitted ? (
          <div>
            {/* Modal Header */}
            <div className="mb-8">
              <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full glass-badge mb-3 border border-white/10">
                <Sparkles className="w-3.5 h-3.5 text-[#E31837]" />
                <span className="text-[10px] font-mono tracking-widest uppercase text-zinc-300">
                  EXCLUSIVE VIP ACCESS
                </span>
              </div>
              <h3 className="text-2xl sm:text-3xl font-display font-extrabold text-white">
                EXPERIENCE THE <span className="text-gradient-red">MAHINDRA BE.05</span>
              </h3>
              <p className="text-xs sm:text-sm text-zinc-400 font-light mt-1">
                Book a personalized test drive with a Mahindra EV product specialist.
              </p>
            </div>

            {/* Form */}
            <form onSubmit={handleSubmit} className="space-y-4 sm:space-y-5">
              {/* Model Choice */}
              <div>
                <label className="block text-xs font-mono uppercase tracking-wider text-zinc-400 mb-1.5">
                  Select Vehicle Model
                </label>
                <div className="grid grid-cols-2 gap-2">
                  {[
                    'Mahindra BE.05 Electric Coupe',
                    'Mahindra BE 6e Performance',
                    'Mahindra XUV.e9 Flagship',
                    'Mahindra Thar.e 4x4',
                  ].map((m) => (
                    <button
                      type="button"
                      key={m}
                      onClick={() => setFormData({ ...formData, model: m })}
                      className={`p-2.5 rounded-xl text-left text-xs font-medium border transition-all ${
                        formData.model === m
                          ? 'bg-[#E31837]/20 border-[#E31837] text-white'
                          : 'bg-white/5 border-white/5 text-zinc-400 hover:text-zinc-200'
                      }`}
                    >
                      {m}
                    </button>
                  ))}
                </div>
              </div>

              {/* Personal Info Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-mono uppercase tracking-wider text-zinc-400 mb-1">
                    Full Name *
                  </label>
                  <div className="relative">
                    <User className="w-4 h-4 text-zinc-500 absolute left-3.5 top-1/2 -translate-y-1/2" />
                    <input
                      type="text"
                      required
                      placeholder="e.g. Vikram Sharma"
                      value={formData.fullName}
                      onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
                      className="w-full bg-white/5 border border-white/10 rounded-xl pl-10 pr-4 py-2.5 text-xs sm:text-sm text-white placeholder-zinc-500 focus:outline-none focus:border-[#E31837] transition-colors"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-mono uppercase tracking-wider text-zinc-400 mb-1">
                    Phone Number *
                  </label>
                  <div className="relative">
                    <Phone className="w-4 h-4 text-zinc-500 absolute left-3.5 top-1/2 -translate-y-1/2" />
                    <input
                      type="tel"
                      required
                      placeholder="+91 98765 43210"
                      value={formData.phone}
                      onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                      className="w-full bg-white/5 border border-white/10 rounded-xl pl-10 pr-4 py-2.5 text-xs sm:text-sm text-white placeholder-zinc-500 focus:outline-none focus:border-[#E31837] transition-colors"
                    />
                  </div>
                </div>
              </div>

              {/* Email */}
              <div>
                <label className="block text-xs font-mono uppercase tracking-wider text-zinc-400 mb-1">
                  Email Address *
                </label>
                <div className="relative">
                  <Mail className="w-4 h-4 text-zinc-500 absolute left-3.5 top-1/2 -translate-y-1/2" />
                  <input
                    type="email"
                    required
                    placeholder="vikram.sharma@example.com"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    className="w-full bg-white/5 border border-white/10 rounded-xl pl-10 pr-4 py-2.5 text-xs sm:text-sm text-white placeholder-zinc-500 focus:outline-none focus:border-[#E31837] transition-colors"
                  />
                </div>
              </div>

              {/* Location Selectors */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-mono uppercase tracking-wider text-zinc-400 mb-1">
                    City
                  </label>
                  <select
                    value={formData.city}
                    onChange={(e) => handleCityChange(e.target.value)}
                    className="w-full bg-[#111116] border border-white/10 rounded-xl px-3.5 py-2.5 text-xs sm:text-sm text-white focus:outline-none focus:border-[#E31837]"
                  >
                    {Object.keys(citiesWithDealerships).map((c) => (
                      <option key={c} value={c} className="bg-[#111116] text-white">
                        {c}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-mono uppercase tracking-wider text-zinc-400 mb-1">
                    Preferred Experience Center
                  </label>
                  <select
                    value={formData.dealership}
                    onChange={(e) => setFormData({ ...formData, dealership: e.target.value })}
                    className="w-full bg-[#111116] border border-white/10 rounded-xl px-3.5 py-2.5 text-xs sm:text-sm text-white focus:outline-none focus:border-[#E31837]"
                  >
                    {(citiesWithDealerships[formData.city] || []).map((d) => (
                      <option key={d} value={d} className="bg-[#111116] text-white">
                        {d}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Date & Time */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-mono uppercase tracking-wider text-zinc-400 mb-1">
                    Preferred Date
                  </label>
                  <input
                    type="date"
                    required
                    value={formData.preferredDate}
                    onChange={(e) => setFormData({ ...formData, preferredDate: e.target.value })}
                    className="w-full bg-white/5 border border-white/10 rounded-xl px-3.5 py-2.5 text-xs sm:text-sm text-white focus:outline-none focus:border-[#E31837]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-mono uppercase tracking-wider text-zinc-400 mb-1">
                    Preferred Time Slot
                  </label>
                  <select
                    value={formData.timeSlot}
                    onChange={(e) => setFormData({ ...formData, timeSlot: e.target.value })}
                    className="w-full bg-[#111116] border border-white/10 rounded-xl px-3.5 py-2.5 text-xs sm:text-sm text-white focus:outline-none focus:border-[#E31837]"
                  >
                    <option value="10:00 AM – 12:00 PM">Morning (10:00 AM – 12:00 PM)</option>
                    <option value="12:00 PM – 02:00 PM">Afternoon (12:00 PM – 02:00 PM)</option>
                    <option value="02:00 PM – 04:00 PM">Evening (02:00 PM – 04:00 PM)</option>
                    <option value="04:00 PM – 06:00 PM">Twilight Drive (04:00 PM – 06:00 PM)</option>
                  </select>
                </div>
              </div>

              {/* Submit Button */}
              <button
                type="submit"
                id="modal-confirm-booking-btn"
                className="w-full py-4 rounded-full bg-[#E31837] text-white font-semibold text-xs sm:text-sm uppercase tracking-[0.2em] shadow-[0_0_30px_rgba(227,24,55,0.6)] hover:bg-[#c0132d] hover:shadow-[0_0_45px_rgba(227,24,55,0.9)] transition-all active:scale-98 flex items-center justify-center space-x-2 mt-4"
              >
                <span>CONFIRM TEST DRIVE RESERVATION</span>
                <ChevronRight className="w-4 h-4" />
              </button>
            </form>
          </div>
        ) : (
          /* Confirmation State */
          <div className="py-8 text-center flex flex-col items-center space-y-6 animate-scale-up">
            <div className="w-16 h-16 rounded-full bg-[#E31837]/20 border border-[#E31837] flex items-center justify-center text-[#E31837] shadow-[0_0_30px_rgba(227,24,55,0.5)]">
              <CheckCircle className="w-8 h-8" />
            </div>

            <div>
              <span className="text-xs font-mono uppercase tracking-widest text-[#E31837] block mb-1">
                RESERVATION CONFIRMED
              </span>
              <h3 className="text-2xl sm:text-3xl font-display font-bold text-white">
                WE LOOK FORWARD TO WELCOMING YOU
              </h3>
              <p className="text-xs sm:text-sm text-zinc-400 max-w-md mx-auto mt-2 font-light">
                Your dedicated Mahindra EV Concierge has been assigned. A confirmation dossier has been sent to{' '}
                <span className="text-white font-medium">{formData.email}</span>.
              </p>
            </div>

            {/* Booking Details Card */}
            <div className="w-full bg-white/5 border border-white/10 rounded-2xl p-4 sm:p-6 text-left text-xs font-mono space-y-2">
              <div className="flex justify-between border-b border-white/5 pb-2">
                <span className="text-zinc-400">BOOKING REF:</span>
                <span className="text-white font-bold">MHD-BE05-8942</span>
              </div>
              <div className="flex justify-between border-b border-white/5 pb-2">
                <span className="text-zinc-400">VEHICLE:</span>
                <span className="text-[#E31837] font-bold">{formData.model}</span>
              </div>
              <div className="flex justify-between border-b border-white/5 pb-2">
                <span className="text-zinc-400">EXPERIENCE CENTER:</span>
                <span className="text-white">{formData.dealership}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-zinc-400">SLOT:</span>
                <span className="text-white">{formData.preferredDate || 'Upcoming Weekend'} ({formData.timeSlot})</span>
              </div>
            </div>

            <button
              onClick={handleReset}
              className="px-8 py-3 rounded-full bg-white/10 border border-white/20 text-white text-xs uppercase tracking-widest hover:bg-white/20 transition-all"
            >
              RETURN TO EXPERIENCE
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
