import React, { useState } from 'react';
import { Eye, Wind, Sparkles, Layers, ShieldCheck, ArrowUpRight } from 'lucide-react';

export const DesignSection: React.FC = () => {
  const [activeTab, setActiveTab] = useState<number>(0);

  const designFeatures = [
    {
      id: 'lighting',
      title: 'Signature LED Matrix',
      subtitle: 'Aero-Sculpted C-DRL Array',
      description:
        'Sharp, razor-cut geometric C-shaped daytime running lights that announce your presence with an animated welcome choreography as you approach.',
      image: '/images/signature_lighting.webp',
      stats: '64-Zone Adaptive Matrix',
    },
    {
      id: 'aero',
      title: 'Sculpted Aero Silhouette',
      subtitle: 'Cd 0.26 Drag Coefficient',
      description:
        'A fastback coupe roofline crafted through over 400 hours of wind tunnel testing, channeling airflow seamlessly over active rear spoilers and integrated air curtains.',
      image: '/images/aero_profile.webp',
      stats: '18% Range Optimization',
    },
    {
      id: 'interior',
      title: 'Driver-Centric Cockpit',
      subtitle: 'Seamless Dual 12.3" Panoramic Arc',
      description:
        'Crafted with recycled sustainable Alcantara and premium vegan leather, wrapping the driver in a cocoon of digital intelligence and tactical comfort.',
      image: '/images/interior_cockpit.webp',
      stats: 'Zero-Gravity Ergonomics',
    },
  ];

  return (
    <section id="design" className="relative py-28 sm:py-36 bg-[#060608] overflow-hidden">
      {/* Background ambient lighting */}
      <div className="absolute top-1/4 right-0 w-[500px] h-[500px] bg-[#E31837]/10 rounded-full blur-[120px] pointer-events-none" />
      <div className="absolute bottom-10 left-0 w-[400px] h-[400px] bg-sky-500/5 rounded-full blur-[100px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-16 sm:mb-20 pb-8 border-b border-white/10">
          <div>
            <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full glass-badge mb-4 border border-white/10">
              <Sparkles className="w-3.5 h-3.5 text-[#E31837]" />
              <span className="text-[11px] font-mono tracking-[0.25em] uppercase text-zinc-400">
                AESTHETICS & ARCHITECTURE
              </span>
            </div>
            <h2 className="text-3xl sm:text-5xl lg:text-6xl font-display font-extrabold text-white tracking-tight">
              DESIGNED TO BE <span className="text-gradient-red">SEEN.</span>
            </h2>
          </div>
          <p className="mt-4 md:mt-0 text-sm sm:text-base text-zinc-400 max-w-md font-light leading-relaxed">
            Every crease and contour is engineered with intention. Bold proportions meet cutting-edge aerodynamics in Mahindra’s most athletic silhouette ever.
          </p>
        </div>

        {/* Feature Interactive Showcase Tabs */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center mb-16">
          {/* Main Visual Display */}
          <div className="lg:col-span-7">
            <div className="relative rounded-3xl overflow-hidden glass-card border border-white/15 aspect-[16/10] group">
              <img
                src={designFeatures[activeTab].image}
                alt={designFeatures[activeTab].title}
                className="w-full h-full object-cover object-center transform transition-transform duration-700 group-hover:scale-105"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#060608] via-transparent to-transparent opacity-80" />

              {/* Floating Stat Pill */}
              <div className="absolute bottom-6 left-6 right-6 flex items-center justify-between p-4 rounded-2xl glass-panel border border-white/15">
                <div>
                  <span className="text-[10px] font-mono uppercase tracking-widest text-[#E31837] block">
                    ENGINEERING BENCHMARK
                  </span>
                  <span className="text-base sm:text-lg font-bold font-display text-white">
                    {designFeatures[activeTab].stats}
                  </span>
                </div>
                <div className="w-9 h-9 rounded-full bg-[#E31837]/20 border border-[#E31837]/40 flex items-center justify-center text-[#E31837]">
                  <ArrowUpRight className="w-5 h-5" />
                </div>
              </div>
            </div>
          </div>

          {/* Interactive Feature Selectors */}
          <div className="lg:col-span-5 flex flex-col space-y-4">
            {designFeatures.map((feature, idx) => (
              <div
                key={feature.id}
                onClick={() => setActiveTab(idx)}
                className={`cursor-pointer p-6 rounded-2xl transition-all duration-300 border ${
                  activeTab === idx
                    ? 'bg-white/10 border-[#E31837] shadow-[0_10px_30px_rgba(227,24,55,0.15)] translate-x-2'
                    : 'bg-white/[0.02] border-white/5 hover:border-white/20 hover:bg-white/[0.05]'
                }`}
              >
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-mono font-bold text-[#E31837]">
                    0{idx + 1}
                  </span>
                  <span className="text-[11px] font-mono tracking-wider uppercase text-zinc-500">
                    {feature.subtitle}
                  </span>
                </div>
                <h3 className="text-xl font-display font-bold text-white mb-2">
                  {feature.title}
                </h3>
                <p className="text-xs sm:text-sm text-zinc-400 font-light leading-relaxed">
                  {feature.description}
                </p>
              </div>
            ))}
          </div>
        </div>

        {/* 4 Feature Spec Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          <div className="glass-card p-6 rounded-2xl border border-white/10 hover:border-[#E31837]/40 transition-all">
            <div className="w-10 h-10 rounded-xl bg-white/5 border border-white/10 flex items-center justify-center text-[#E31837] mb-4">
              <Eye className="w-5 h-5" />
            </div>
            <h4 className="text-base font-display font-bold text-white mb-2">
              Signature LED Lighting
            </h4>
            <p className="text-xs text-zinc-400 leading-relaxed font-light">
              High-intensity projection optics with adaptive cornering assistance for maximum night visibility.
            </p>
          </div>

          <div className="glass-card p-6 rounded-2xl border border-white/10 hover:border-[#E31837]/40 transition-all">
            <div className="w-10 h-10 rounded-xl bg-white/5 border border-white/10 flex items-center justify-center text-[#E31837] mb-4">
              <Layers className="w-5 h-5" />
            </div>
            <h4 className="text-base font-display font-bold text-white mb-2">
              Sculpted Body Design
            </h4>
            <p className="text-xs text-zinc-400 leading-relaxed font-light">
              Athletic wide-track stance with chiseled haunches and bold 20-inch aero-blade alloy wheels.
            </p>
          </div>

          <div className="glass-card p-6 rounded-2xl border border-white/10 hover:border-[#E31837]/40 transition-all">
            <div className="w-10 h-10 rounded-xl bg-white/5 border border-white/10 flex items-center justify-center text-[#E31837] mb-4">
              <Wind className="w-5 h-5" />
            </div>
            <h4 className="text-base font-display font-bold text-white mb-2">
              Aerodynamic Profile
            </h4>
            <p className="text-xs text-zinc-400 leading-relaxed font-light">
              Active front grille shutters and flush pop-out smart handles reduce turbulence and wind drag.
            </p>
          </div>

          <div className="glass-card p-6 rounded-2xl border border-white/10 hover:border-[#E31837]/40 transition-all">
            <div className="w-10 h-10 rounded-xl bg-white/5 border border-white/10 flex items-center justify-center text-[#E31837] mb-4">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <h4 className="text-base font-display font-bold text-white mb-2">
              Ultra-High-Strength Shell
            </h4>
            <p className="text-xs text-zinc-400 leading-relaxed font-light">
              Hot-stamped boron steel reinforced safety cage exceeding Global NCAP 5-Star impact standards.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};
