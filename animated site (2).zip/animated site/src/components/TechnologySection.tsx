import React, { useState } from 'react';
import { Cpu, Wifi, Radio, ShieldAlert, Disc, Smartphone, RefreshCw, Sparkles, Navigation } from 'lucide-react';

export const TechnologySection: React.FC = () => {
  const [radarScanning, setRadarScanning] = useState(true);
  const [activeAdasFeature, setActiveAdasFeature] = useState(0);

  const adasFeatures = [
    {
      title: 'Adaptive Cruise with Stop & Go',
      desc: 'Maintains ideal spacing and navigates stop-and-go traffic seamlessly up to 160 km/h.',
      range: '200m Forward Range',
    },
    {
      title: 'Lane Centering & Active Steer',
      desc: 'Continuous micro-steering torque to maintain precise track alignment even on winding curves.',
      range: '360° Surround Vision',
    },
    {
      title: 'Autonomous Emergency Braking (AEB)',
      desc: 'Detects pedestrians, cyclists, and cross-traffic intersections with instant milli-second braking.',
      range: '0.04s Response Time',
    },
    {
      title: 'Automated Valet Park Assist',
      desc: 'Ultrasonic sensors scan and park into perpendicular, parallel, or tight garage spaces autonomously.',
      range: '12 Ultrasonic Sensors',
    },
  ];

  return (
    <section id="technology" className="relative py-28 sm:py-36 bg-[#060608] text-white overflow-hidden">
      {/* Background cyber grid & glow */}
      <div className="absolute top-1/2 left-0 w-[500px] h-[500px] bg-sky-500/10 rounded-full blur-[130px] pointer-events-none" />
      <div className="absolute bottom-10 right-0 w-[500px] h-[500px] bg-[#E31837]/10 rounded-full blur-[130px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-16 sm:mb-20 pb-8 border-b border-white/10">
          <div>
            <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full glass-badge mb-4 border border-white/10">
              <Cpu className="w-3.5 h-3.5 text-sky-400" />
              <span className="text-[11px] font-mono tracking-[0.25em] uppercase text-zinc-400">
                COGNITIVE ARCHITECTURE
              </span>
            </div>
            <h2 className="text-3xl sm:text-5xl lg:text-6xl font-display font-extrabold text-white tracking-tight">
              INTELLIGENCE, <span className="text-gradient-red">IN MOTION.</span>
            </h2>
          </div>
          <p className="mt-4 md:mt-0 text-sm sm:text-base text-zinc-400 max-w-md font-light leading-relaxed">
            Powered by high-throughput neural computing and high-density sensory arrays, the vehicle continuously perceives, adapts, and evolves with you.
          </p>
        </div>

        {/* Feature Grid with Interactive ADAS Simulator */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 mb-12">
          {/* Left Column: Interactive ADAS 360 LiDAR Vision Box */}
          <div className="lg:col-span-7 glass-card p-6 sm:p-8 rounded-3xl border border-white/15 relative overflow-hidden flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between mb-6">
                <div className="flex items-center space-x-2">
                  <ShieldAlert className="w-5 h-5 text-[#E31837]" />
                  <span className="text-xs font-mono uppercase tracking-widest text-white font-bold">
                    LEVEL 2+ ADAS RADAR SENSORY SUITE
                  </span>
                </div>
                <button
                  onClick={() => setRadarScanning(!radarScanning)}
                  className="px-3 py-1 rounded-full text-[10px] font-mono bg-white/10 border border-white/15 hover:bg-white/20 transition-all text-zinc-300"
                >
                  {radarScanning ? 'PAUSE SCAN' : 'RESUME SCAN'}
                </button>
              </div>

              {/* Radar Sweep Interactive Canvas Simulation */}
              <div className="relative w-full aspect-[16/9] bg-black/60 rounded-2xl border border-white/10 overflow-hidden flex items-center justify-center mb-6">
                {/* Concentric distance rings */}
                <div className="absolute w-[80%] h-[80%] rounded-full border border-sky-500/20" />
                <div className="absolute w-[55%] h-[55%] rounded-full border border-sky-500/25" />
                <div className="absolute w-[30%] h-[30%] rounded-full border border-sky-500/30" />

                {/* Radar beam rotation */}
                {radarScanning && (
                  <div
                    className="absolute inset-0 origin-center pointer-events-none"
                    style={{
                      background:
                        'conic-gradient(from 0deg at 50% 50%, rgba(56, 189, 248, 0.3) 0deg, transparent 60deg, transparent 360deg)',
                      animation: 'spin 3.5s linear infinite',
                    }}
                  />
                )}

                {/* Vehicle Centered Icon */}
                <div className="relative z-10 w-12 h-20 rounded-xl bg-[#E31837]/20 border border-[#E31837] flex flex-col items-center justify-center text-center shadow-[0_0_20px_rgba(227,24,55,0.6)]">
                  <span className="text-[8px] font-mono font-bold text-white">MAHINDRA</span>
                  <div className="w-1.5 h-1.5 rounded-full bg-white animate-ping mt-1" />
                </div>

                {/* Detected Object Blips */}
                <div className="absolute top-[25%] left-[30%] flex items-center space-x-1 animate-pulse">
                  <div className="w-2 h-2 rounded-full bg-emerald-400 shadow-[0_0_8px_#34d399]" />
                  <span className="text-[9px] font-mono text-emerald-400 bg-black/60 px-1 rounded">VEHICLE [42m]</span>
                </div>

                <div className="absolute bottom-[30%] right-[25%] flex items-center space-x-1 animate-pulse">
                  <div className="w-2 h-2 rounded-full bg-sky-400 shadow-[0_0_8px_#38bdf8]" />
                  <span className="text-[9px] font-mono text-sky-400 bg-black/60 px-1 rounded">LANE OK</span>
                </div>

                <div className="absolute top-[35%] right-[28%] flex items-center space-x-1 animate-pulse">
                  <div className="w-2 h-2 rounded-full bg-amber-400 shadow-[0_0_8px_#fbbf24]" />
                  <span className="text-[9px] font-mono text-amber-400 bg-black/60 px-1 rounded">PEDESTRIAN [18m]</span>
                </div>

                {/* Status bar bottom overlay */}
                <div className="absolute bottom-2 left-3 right-3 flex items-center justify-between text-[10px] font-mono text-zinc-400 bg-black/80 px-3 py-1.5 rounded-lg border border-white/10">
                  <span className="text-sky-400">● 5 RADARS + 12 CAMERAS ACTIVE</span>
                  <span>LATENCY: 12ms</span>
                </div>
              </div>
            </div>

            {/* ADAS Feature Selector */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {adasFeatures.map((feat, idx) => (
                <button
                  key={idx}
                  onClick={() => setActiveAdasFeature(idx)}
                  className={`p-2.5 rounded-xl text-left border text-xs transition-all duration-200 ${
                    activeAdasFeature === idx
                      ? 'bg-sky-500/20 border-sky-400 text-white font-semibold'
                      : 'bg-white/5 border-white/5 text-zinc-400 hover:text-white'
                  }`}
                >
                  <span className="block text-[10px] font-mono text-sky-400">0{idx + 1}</span>
                  <span className="line-clamp-1">{feat.title}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Right Column: Dual-Screen & Connected Cockpit */}
          <div className="lg:col-span-5 flex flex-col space-y-6">
            {/* Qualcomm Snapdragon Cinema Cockpit */}
            <div className="glass-card p-6 sm:p-8 rounded-3xl border border-white/15 relative overflow-hidden group">
              <div className="w-10 h-10 rounded-xl bg-sky-500/10 border border-sky-500/20 flex items-center justify-center text-sky-400 mb-4">
                <Cpu className="w-5 h-5" />
              </div>
              <h3 className="text-xl font-display font-bold text-white mb-2">
                Snapdragon® Digital Chassis
              </h3>
              <p className="text-xs sm:text-sm text-zinc-400 font-light leading-relaxed mb-4">
                Dual 12.3-inch curved continuous high-resolution displays operating at 60 FPS with zero lag, powered by multi-core neural processing.
              </p>
              <div className="flex items-center space-x-2 text-xs font-mono text-sky-400">
                <span>● 8K UI ACCELERATION</span>
                <span>|</span>
                <span>5G CONNECTED</span>
              </div>
            </div>

            {/* Spatial Audio Card */}
            <div className="glass-card p-6 sm:p-8 rounded-3xl border border-white/15 relative overflow-hidden group">
              <div className="w-10 h-10 rounded-xl bg-[#E31837]/10 border border-[#E31837]/20 flex items-center justify-center text-[#E31837] mb-4">
                <Disc className="w-5 h-5" />
              </div>
              <h3 className="text-xl font-display font-bold text-white mb-2">
                Harman Kardon 16-Speaker Spatial Audio
              </h3>
              <p className="text-xs sm:text-sm text-zinc-400 font-light leading-relaxed mb-4">
                Equipped with Dolby Atmos 3D immersive sound, headrest speakers, and customized EV soundscapes tuned by legendary acoustic sound designers.
              </p>
              <div className="flex items-center space-x-2 text-xs font-mono text-[#E31837]">
                <span>● 825W PEAK AMPLIFICATION</span>
              </div>
            </div>
          </div>
        </div>

        {/* 3 Tech Pillars Row */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
          <div className="glass-card p-6 rounded-2xl border border-white/10">
            <div className="w-9 h-9 rounded-xl bg-white/5 border border-white/10 flex items-center justify-center text-sky-400 mb-3">
              <Smartphone className="w-4 h-4" />
            </div>
            <h4 className="text-sm font-display font-bold text-white mb-1">
              Digital Key & Remote Telematics
            </h4>
            <p className="text-xs text-zinc-400 font-light leading-relaxed">
              Unlock via Apple CarKey or Android UWB, schedule pre-cooling, and monitor battery telemetry globally.
            </p>
          </div>

          <div className="glass-card p-6 rounded-2xl border border-white/10">
            <div className="w-9 h-9 rounded-xl bg-white/5 border border-white/10 flex items-center justify-center text-[#E31837] mb-3">
              <RefreshCw className="w-4 h-4" />
            </div>
            <h4 className="text-sm font-display font-bold text-white mb-1">
              Over-The-Air (OTA) Intelligence
            </h4>
            <p className="text-xs text-zinc-400 font-light leading-relaxed">
              Continuous software improvements expand range efficiency, autonomous driving skills, and infotainment features.
            </p>
          </div>

          <div className="glass-card p-6 rounded-2xl border border-white/10">
            <div className="w-9 h-9 rounded-xl bg-white/5 border border-white/10 flex items-center justify-center text-amber-400 mb-3">
              <Navigation className="w-4 h-4" />
            </div>
            <h4 className="text-sm font-display font-bold text-white mb-1">
              Augmented Reality Head-Up Display
            </h4>
            <p className="text-xs text-zinc-400 font-light leading-relaxed">
              Projects turn-by-turn navigation arrows and lane guidance directly onto the windshield in real-time.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};
