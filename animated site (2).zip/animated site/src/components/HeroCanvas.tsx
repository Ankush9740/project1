import React, { useRef, useEffect, useState, useCallback } from 'react';
import { HeroOverlays } from './HeroOverlays';
import { TOTAL_FRAMES } from '../utils/frameLoader';
import { RotateCw, MousePointer, Sparkles } from 'lucide-react';

interface HeroCanvasProps {
  images: HTMLImageElement[];
  onExplore: () => void;
  onBookTestDrive: () => void;
}

export const HeroCanvas: React.FC<HeroCanvasProps> = ({
  images,
  onExplore,
  onBookTestDrive,
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  // Animation and scrub states
  const [scrollProgress, setScrollProgress] = useState<number>(0);
  const [isDragMode, setIsDragMode] = useState<boolean>(false);
  const [isDragging, setIsDragging] = useState<boolean>(false);
  const [dragProgress, setDragProgress] = useState<number>(0);

  // Refs for requestAnimationFrame loop
  const currentFrameRef = useRef<number>(0);
  const targetFrameRef = useRef<number>(0);
  const animFrameIdRef = useRef<number | null>(null);
  const lastDrawnFrameRef = useRef<number>(-1);
  const dragStartXRef = useRef<number>(0);
  const dragStartProgressRef = useRef<number>(0);

  // Draw a frame onto the canvas with proper aspect ratio and studio vignette
  const drawFrame = useCallback(
    (frameIndex: number) => {
      const canvas = canvasRef.current;
      if (!canvas || !images || images.length === 0) return;
      const ctx = canvas.getContext('2d', { alpha: false });
      if (!ctx) return;

      const img = images[Math.floor(frameIndex)];
      if (!img || !img.complete || img.naturalWidth === 0) return;

      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      const width = canvas.clientWidth;
      const height = canvas.clientHeight;

      if (canvas.width !== width * dpr || canvas.height !== height * dpr) {
        canvas.width = width * dpr;
        canvas.height = height * dpr;
      }

      ctx.save();
      ctx.scale(dpr, dpr);

      // Studio dark background fill
      ctx.fillStyle = '#060608';
      ctx.fillRect(0, 0, width, height);

      // Calculate aspect ratio containment
      const imgAspect = 1280 / 720;
      const canvasAspect = width / height;

      let drawWidth = width;
      let drawHeight = height;
      let offsetX = 0;
      let offsetY = 0;

      if (canvasAspect > imgAspect) {
        // Wider screen - fit to height or slightly scale
        drawHeight = height;
        drawWidth = height * imgAspect;
        offsetX = (width - drawWidth) / 2;
        offsetY = 0;
      } else {
        // Taller screen - fit to width or center
        drawWidth = width;
        drawHeight = width / imgAspect;
        offsetX = 0;
        offsetY = (height - drawHeight) / 2;
      }

      // Draw the crisp automotive frame
      ctx.drawImage(img, offsetX, offsetY, drawWidth, drawHeight);

      // Subtle studio edge vignette & floor gradient blend for ultra-premium look
      const vignette = ctx.createRadialGradient(
        width / 2,
        height / 2,
        Math.min(width, height) * 0.35,
        width / 2,
        height / 2,
        Math.max(width, height) * 0.75
      );
      vignette.addColorStop(0, 'rgba(6, 6, 8, 0)');
      vignette.addColorStop(0.7, 'rgba(6, 6, 8, 0.25)');
      vignette.addColorStop(1, 'rgba(6, 6, 8, 0.85)');
      ctx.fillStyle = vignette;
      ctx.fillRect(0, 0, width, height);

      ctx.restore();
      lastDrawnFrameRef.current = frameIndex;
    },
    [images]
  );

  // Render loop with smooth lerping
  useEffect(() => {
    let active = true;

    const renderLoop = () => {
      if (!active) return;

      const target = targetFrameRef.current;
      const current = currentFrameRef.current;
      const diff = target - current;

      if (Math.abs(diff) > 0.01) {
        // Smooth lerp easing (0.16 factor for instantaneous yet buttery response)
        currentFrameRef.current += diff * 0.16;
        const boundedIndex = Math.min(
          TOTAL_FRAMES - 1,
          Math.max(0, Math.round(currentFrameRef.current))
        );
        drawFrame(boundedIndex);
      } else if (lastDrawnFrameRef.current !== Math.round(target)) {
        currentFrameRef.current = target;
        drawFrame(Math.round(target));
      }

      animFrameIdRef.current = requestAnimationFrame(renderLoop);
    };

    animFrameIdRef.current = requestAnimationFrame(renderLoop);

    return () => {
      active = false;
      if (animFrameIdRef.current) {
        cancelAnimationFrame(animFrameIdRef.current);
      }
    };
  }, [drawFrame]);

  // Handle Scroll progress calculation
  useEffect(() => {
    if (isDragMode) return;

    const handleScroll = () => {
      const container = containerRef.current;
      if (!container) return;

      const rect = container.getBoundingClientRect();
      const scrollableHeight = container.scrollHeight - window.innerHeight;

      if (scrollableHeight <= 0) return;

      // Calculate progress from 0 to 1 based on container's position in viewport
      const currentY = -rect.top;
      const progress = Math.max(0, Math.min(1, currentY / scrollableHeight));

      setScrollProgress(progress);

      // Target frame calculation
      const target = progress * (TOTAL_FRAMES - 1);
      targetFrameRef.current = target;
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    window.addEventListener('resize', handleScroll);
    handleScroll();

    return () => {
      window.removeEventListener('scroll', handleScroll);
      window.removeEventListener('resize', handleScroll);
    };
  }, [isDragMode]);

  // Redraw when images are initially loaded or window resized
  useEffect(() => {
    if (images && images.length > 0) {
      drawFrame(0);
    }
  }, [images, drawFrame]);

  // Interactive 360 drag handlers
  const handleMouseDown = (e: React.MouseEvent) => {
    if (!isDragMode) return;
    setIsDragging(true);
    dragStartXRef.current = e.clientX;
    dragStartProgressRef.current = dragProgress;
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isDragMode || !isDragging) return;
    const deltaX = e.clientX - dragStartXRef.current;
    const sensitivity = 0.003;
    let newProgress = dragStartProgressRef.current + deltaX * sensitivity;

    // Wrap around 0 to 1 for infinite 360 spinning
    newProgress = ((newProgress % 1) + 1) % 1;

    setDragProgress(newProgress);
    setScrollProgress(newProgress);
    targetFrameRef.current = newProgress * (TOTAL_FRAMES - 1);
  };

  const handleMouseUp = () => {
    setIsDragging(false);
  };

  // Touch drag handlers
  const handleTouchStart = (e: React.TouchEvent) => {
    if (!isDragMode || e.touches.length === 0) return;
    setIsDragging(true);
    dragStartXRef.current = e.touches[0].clientX;
    dragStartProgressRef.current = dragProgress;
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    if (!isDragMode || !isDragging || e.touches.length === 0) return;
    const deltaX = e.touches[0].clientX - dragStartXRef.current;
    const sensitivity = 0.004;
    let newProgress = dragStartProgressRef.current + deltaX * sensitivity;
    newProgress = ((newProgress % 1) + 1) % 1;

    setDragProgress(newProgress);
    setScrollProgress(newProgress);
    targetFrameRef.current = newProgress * (TOTAL_FRAMES - 1);
  };

  const handleTouchEnd = () => {
    setIsDragging(false);
  };

  return (
    <section
      ref={containerRef}
      id="hero"
      className="relative w-full h-[380vh] sm:h-[420vh] bg-[#060608]"
    >
      {/* Sticky Full-Viewport Container */}
      <div className="sticky top-0 h-screen w-full overflow-hidden flex items-center justify-center">
        {/* Canvas Renderer */}
        <canvas
          ref={canvasRef}
          className={`w-full h-full object-contain block ${
            isDragMode ? 'cursor-grab active:cursor-grabbing' : 'cursor-default'
          }`}
          onMouseDown={handleMouseDown}
          onMouseMove={handleMouseMove}
          onMouseUp={handleMouseUp}
          onMouseLeave={handleMouseUp}
          onTouchStart={handleTouchStart}
          onTouchMove={handleTouchMove}
          onTouchEnd={handleTouchEnd}
        />

        {/* Ambient Red Aura Spotlight */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[80vw] h-[70vh] bg-radial from-[#E31837]/15 to-transparent blur-3xl pointer-events-none -z-10" />

        {/* Floating Controls Mode Switcher (Scroll vs 360 Spin) */}
        <div className="absolute bottom-8 left-6 sm:left-12 z-30 flex items-center space-x-2">
          <button
            onClick={() => {
              setIsDragMode(!isDragMode);
              if (!isDragMode) {
                setDragProgress(scrollProgress);
              }
            }}
            className={`px-3.5 py-1.5 rounded-full text-xs font-mono tracking-wider uppercase transition-all duration-300 flex items-center space-x-2 backdrop-blur-xl border ${
              isDragMode
                ? 'bg-[#E31837] text-white border-[#E31837] shadow-[0_0_15px_rgba(227,24,55,0.5)]'
                : 'bg-black/60 text-zinc-300 border-white/10 hover:border-white/30'
            }`}
            title="Toggle between scroll scrubbing and 360 mouse dragging"
          >
            {isDragMode ? (
              <>
                <MousePointer className="w-3.5 h-3.5 animate-bounce" />
                <span>360° DRAG ACTIVE</span>
              </>
            ) : (
              <>
                <RotateCw className="w-3.5 h-3.5" />
                <span>ENABLE 360° DRAG</span>
              </>
            )}
          </button>

          {isDragMode && (
            <span className="hidden sm:inline text-[11px] font-mono text-zinc-400 animate-pulse">
              ← Drag left or right to spin the SUV →
            </span>
          )}
        </div>

        {/* Synchronized Hero Overlays */}
        <HeroOverlays
          scrollProgress={scrollProgress}
          onExplore={onExplore}
          onBookTestDrive={onBookTestDrive}
        />
      </div>
    </section>
  );
};
