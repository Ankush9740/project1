import React, { useState } from 'react';
import { Sparkles, Check, ChevronRight, Layers, Sliders, ShieldCheck, Zap } from 'lucide-react';
import { ExteriorColor, WheelOption } from '../types';

interface ConfiguratorSectionProps {
  onBookTestDrive: () => void;
}

export const ConfiguratorSection: React.FC<ConfiguratorSectionProps> = ({ onBookTestDrive }) => {
  const exteriorColors: ExteriorColor[] = [
    {
      id: 'crimson',
      name: 'Blaze Crimson Red',
      hex: '#E31837',
      finish: 'Metallic Multi-Coat',
      description: 'Signature vibrant crimson with deep gloss metallic flake.',
    },
    {
      id: 'obsidian',
      name: 'Stealth Obsidian Black',
      hex: '#18181B',
      finish: 'Deep Gloss Piano',
      description: 'Ultra-dark stealth finish that absorbs reflections with bold presence.',
    },
    {
      id: 'grey',
      name: 'Cyber Satin Grey',
      hex: '#71717A',
      finish: 'Matte Frosted Liquid',
      description: 'Modern architectural satin grey highlighting every aerodynamic body line.',
    },
    {
      id: 'white',
      name: 'Everest Glacier White',
      hex: '#F8FAFC',
      finish: 'Pearl Metallic',
      description: 'Pristine arctic white with subtle prismatic crystal highlights.',
    },
  ];

  const wheelOptions: WheelOption[] = [
    {
      id: 'aero-20',
      name: '20" Aero Blade Alloys',
      size: '20 inch',
      design: 'Directional Aero Carbon Inserts',
      efficiencyGain: '+15 km Range',
    },
    {
      id: 'dark-21',
      name: '21" Track Diamond Cut',
      size: '21 inch',
      design: 'Forged Satin Obsidian Finish',
      efficiencyGain: 'Max Road Grip',
    },
    {
      id: 'stream-19',
      name: '19" Streamline Turbine',
      size: '19 inch',
      design: 'Optimized Aero Surface',
      efficiencyGain: '+25 km Range',
    },
  ];

  const trims = [
    {
      id: 'dual',
      name: 'BE.05 Performance AWD',
      hp: '335 HP',
      accel: '3.5s (0-100)',
      range: '550 km',
      battery: '79 kWh',
      price: '₹ 28,90,000',
    },
    {
      id: 'long',
      name: 'BE.05 Long-Range RWD',
      hp: '282 HP',
      accel: '4.8s (0-100)',
      range: '620 km',
      battery: '79 kWh',
      price: '₹ 24,90,000',
    },
  ];

  const [selectedColor, setSelectedColor] = useState<ExteriorColor>(exteriorColors[0]);
  const [selectedWheel, setSelectedWheel] = useState<WheelOption>(wheelOptions[0]);
  const [selectedTrim, setSelectedTrim] = useState(trims[0]);

  return (
    <section id="configurator" className="relative py-28 sm:py-36 bg-[#060608] text-white overflow-hidden">
      {/* Background radial highlight */}
      <div className="absolute top-1/2 right-10 w-[600px] h-[600px] bg-[#E31837]/10 rounded-full blur-[150px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-16 pb-8 border-b border-white/10">
          <div>
            <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full glass-badge mb-4 border border-white/10">
              <Sliders className="w-3.5 h-3.5 text-[#E31837]" />
              <span className="text-[11px] font-mono tracking-[0.25em] uppercase text-zinc-400">
                STUDIO CONFIGURATOR
              </span>
            </div>
            <h2 className="text-3xl sm:text-5xl lg:text-6xl font-display font-extrabold text-white tracking-tight">
              PERSONALIZE YOUR <span className="text-gradient-red">BE.05.</span>
            </h2>
          </div>
          <p className="mt-4 md:mt-0 text-sm sm:text-base text-zinc-400 max-w-md font-light leading-relaxed">
            Craft your bespoke Mahindra SUV. Select your powertrain architecture, exterior palette, and aerodynamic wheel styles.
          </p>
        </div>

        {/* Configurator 2-Column Studio Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Left Column: Visual Showcase Preview with Active Finish Highlight */}
          <div className="lg:col-span-7 flex flex-col space-y-6">
            <div className="relative rounded-3xl overflow-hidden glass-card border border-white/15 p-6 sm:p-10 flex flex-col items-center justify-center min-h-[460px]">
              {/* Dynamic Aura Glow matching paint */}
              <div
                className="absolute inset-0 opacity-30 blur-3xl transition-all duration-700 pointer-events-none"
                style={{ backgroundColor: selectedColor.hex === '#18181B' ? '#334155' : selectedColor.hex }}
              />

              {/* Centered Vehicle Silhouette Presentation */}
              <div className="relative z-10 w-full aspect-[16/10] flex items-center justify-center">
                <img
                  src="/images/aero_profile.webp"
                  alt="Vehicle Preview"
                  className="w-full h-full object-cover rounded-2xl filter drop-shadow-[0_20px_40px_rgba(0,0,0,0.9)]"
                  style={{
                    filter:
                      selectedColor.id === 'obsidian'
                        ? 'brightness(0.65) contrast(1.2)'
                        : selectedColor.id === 'grey'
                        ? 'saturate(0.1) brightness(0.85)'
                        : selectedColor.id === 'white'
                        ? 'saturate(0.1) brightness(1.25)'
                        : 'none',
                  }}
                />
              </div>

              {/* Active Color & Wheel Summary Badge */}
              <div className="relative z-10 w-full flex items-center justify-between p-4 sm:p-5 rounded-2xl glass-panel border border-white/15 mt-6">
                <div className="flex items-center space-x-3.5">
                  <div
                    className="w-7 h-7 rounded-full border-2 border-white/40 shadow-sm shrink-0"
                    style={{ backgroundColor: selectedColor.hex }}
                  />
                  <div>
                    <span className="text-sm font-bold text-white block">
                      {selectedColor.name}
                    </span>
                    <span className="text-[10px] font-mono text-zinc-400 uppercase">
                      {selectedColor.finish}
                    </span>
                  </div>
                </div>

                <div className="text-right">
                  <span className="text-xs sm:text-sm font-mono font-bold text-zinc-200 block">
                    {selectedWheel.name}
                  </span>
                  <span className="text-[10px] font-mono text-[#E31837] uppercase font-semibold">
                    {selectedWheel.efficiencyGain}
                  </span>
                </div>
              </div>
            </div>

            {/* Live Specs Matrix */}
            <div className="grid grid-cols-3 gap-3">
              <div className="glass-card p-4 rounded-2xl text-center border border-white/10">
                <span className="text-[10px] font-mono uppercase text-zinc-400 block mb-1">0–100 KM/H</span>
                <span className="text-lg sm:text-xl font-bold font-mono text-white">{selectedTrim.accel}</span>
              </div>
              <div className="glass-card p-4 rounded-2xl text-center border border-white/10">
                <span className="text-[10px] font-mono uppercase text-zinc-400 block mb-1">MAX RANGE</span>
                <span className="text-lg sm:text-xl font-bold font-mono text-white">{selectedTrim.range}</span>
              </div>
              <div className="glass-card p-4 rounded-2xl text-center border border-white/10">
                <span className="text-[10px] font-mono uppercase text-zinc-400 block mb-1">HORSEPOWER</span>
                <span className="text-lg sm:text-xl font-bold font-mono text-[#E31837]">{selectedTrim.hp}</span>
              </div>
            </div>
          </div>

          {/* Right Column: Customization Controls */}
          <div className="lg:col-span-5 flex flex-col space-y-6">
            {/* Step 1: Powertrain Trim Selection */}
            <div className="glass-card p-6 rounded-3xl border border-white/15">
              <span className="text-xs font-mono uppercase tracking-widest text-[#E31837] font-semibold block mb-3">
                01 / SELECT POWERTRAIN
              </span>
              <div className="flex flex-col space-y-3">
                {trims.map((trim) => {
                  const isSelected = selectedTrim.id === trim.id;
                  return (
                    <div
                      key={trim.id}
                      onClick={() => setSelectedTrim(trim)}
                      className={`cursor-pointer p-4 rounded-2xl border transition-all duration-300 ${
                        isSelected
                          ? 'bg-white/10 border-[#E31837] shadow-[0_0_20px_rgba(227,24,55,0.2)]'
                          : 'bg-white/5 border-white/5 hover:border-white/20'
                      }`}
                    >
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-sm font-display font-bold text-white">
                          {trim.name}
                        </span>
                        <span className="text-xs font-mono font-bold text-[#E31837]">
                          {trim.price}*
                        </span>
                      </div>
                      <div className="flex items-center space-x-3 text-xs font-mono text-zinc-400">
                        <span>{trim.hp}</span>
                        <span>•</span>
                        <span>{trim.range}</span>
                        <span>•</span>
                        <span>{trim.accel}</span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Step 2: Exterior Paint Finishes */}
            <div className="glass-card p-6 rounded-3xl border border-white/15">
              <span className="text-xs font-mono uppercase tracking-widest text-[#E31837] font-semibold block mb-3">
                02 / EXTERIOR PAINT SHADE
              </span>
              <div className="grid grid-cols-4 gap-3 mb-4">
                {exteriorColors.map((col) => {
                  const isSelected = selectedColor.id === col.id;
                  return (
                    <button
                      key={col.id}
                      onClick={() => setSelectedColor(col)}
                      className={`h-12 rounded-xl relative flex items-center justify-center transition-all duration-300 border ${
                        isSelected
                          ? 'ring-2 ring-[#E31837] scale-105 border-white'
                          : 'border-white/10 opacity-70 hover:opacity-100'
                      }`}
                      style={{ backgroundColor: col.hex }}
                      title={col.name}
                    >
                      {isSelected && (
                        <Check
                          className={`w-4 h-4 ${
                            col.id === 'white' ? 'text-black' : 'text-white'
                          }`}
                        />
                      )}
                    </button>
                  );
                })}
              </div>
              <div className="bg-white/5 p-3 rounded-xl">
                <span className="text-xs font-bold text-white block">
                  {selectedColor.name}
                </span>
                <p className="text-[11px] text-zinc-400 font-light mt-0.5">
                  {selectedColor.description}
                </p>
              </div>
            </div>

            {/* Step 3: Aero Wheels */}
            <div className="glass-card p-6 rounded-3xl border border-white/15">
              <span className="text-xs font-mono uppercase tracking-widest text-[#E31837] font-semibold block mb-3">
                03 / WHEEL ARCHITECTURE
              </span>
              <div className="grid grid-cols-3 gap-2">
                {wheelOptions.map((wheel) => {
                  const isSelected = selectedWheel.id === wheel.id;
                  return (
                    <button
                      key={wheel.id}
                      onClick={() => setSelectedWheel(wheel)}
                      className={`p-3 rounded-xl text-left border transition-all text-xs ${
                        isSelected
                          ? 'bg-white/15 border-[#E31837] text-white font-bold'
                          : 'bg-white/5 border-white/5 text-zinc-400 hover:text-white'
                      }`}
                    >
                      <span className="block text-[11px] font-mono text-[#E31837]">
                        {wheel.size}
                      </span>
                      <span className="line-clamp-1 mt-0.5">{wheel.name}</span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Price & Action Button */}
            <div className="glass-panel p-6 rounded-3xl border border-white/20 flex flex-col sm:flex-row items-center justify-between gap-4">
              <div>
                <span className="text-[10px] font-mono uppercase tracking-widest text-zinc-400 block">
                  ESTIMATED EX-SHOWROOM
                </span>
                <span className="text-2xl font-display font-extrabold text-white">
                  {selectedTrim.price}
                </span>
              </div>

              <button
                onClick={onBookTestDrive}
                id="configurator-reserve-btn"
                className="w-full sm:w-auto px-6 py-3.5 rounded-full bg-[#E31837] text-white text-xs uppercase tracking-widest font-semibold hover:bg-[#c0132d] hover:shadow-[0_0_25px_rgba(227,24,55,0.6)] transition-all flex items-center justify-center space-x-2"
              >
                <span>RESERVE THIS SPEC</span>
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
