import React, { useState, useEffect } from 'react';
import { Menu, X, ChevronRight, Volume2, VolumeX, Sparkles } from 'lucide-react';

interface NavbarProps {
  onOpenTestDrive: () => void;
  onOpenConfigurator?: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ onOpenTestDrive, onOpenConfigurator }) => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [soundEnabled, setSoundEnabled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 40) {
        setIsScrolled(true);
      } else {
        setIsScrolled(false);
      }
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { name: 'Vehicles', href: '#design' },
    { name: 'Performance', href: '#performance' },
    { name: 'Technology', href: '#technology' },
    { name: 'Interior', href: '#interior' },
    { name: 'Studio', href: '#configurator' },
    { name: 'About', href: '#about' },
  ];

  const handleSoundToggle = () => {
    setSoundEnabled(!soundEnabled);
  };

  return (
    <>
      <header
        className={`fixed top-0 left-0 right-0 z-40 transition-all duration-500 ${
          isScrolled
            ? 'bg-[#060608]/85 backdrop-blur-xl border-b border-white/10 py-3.5 shadow-[0_10px_30px_rgba(0,0,0,0.8)]'
            : 'bg-transparent py-6 border-b border-transparent'
        }`}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center justify-between">
          {/* Brand Logo */}
          <a
            href="#hero"
            className="group flex items-center space-x-3.5 text-white transition-opacity hover:opacity-90 mr-8 lg:mr-12"
            id="nav-brand-logo"
          >
            {/* Minimal Twin Peaks Icon */}
            <div className="w-9 h-9 rounded-xl bg-white/5 border border-white/10 flex items-center justify-center group-hover:border-[#E31837]/50 transition-colors shadow-[0_0_15px_rgba(227,24,55,0.2)]">
              <svg className="w-5 h-5 text-white group-hover:text-[#E31837] transition-colors" viewBox="0 0 100 100" fill="none">
                <path d="M50 15L80 75H65L50 45L35 75H20L50 15Z" fill="currentColor" />
              </svg>
            </div>
            <div className="flex flex-col">
              <span className="font-display font-black tracking-[0.25em] text-lg sm:text-xl text-white">
                MAHINDRA
              </span>
              <span className="text-[9px] font-mono tracking-[0.35em] text-[#E31837] uppercase -mt-0.5 font-bold">
                ELECTRIC
              </span>
            </div>
          </a>

          {/* Desktop Nav Items */}
          <nav className="hidden md:flex items-center space-x-6 lg:space-x-10">
            {navLinks.map((link) => (
              <a
                key={link.name}
                href={link.href}
                className="text-xs uppercase tracking-[0.2em] font-medium text-zinc-300 hover:text-white transition-colors duration-200 relative group py-1"
              >
                {link.name}
                <span className="absolute bottom-0 left-0 w-0 h-[2px] bg-[#E31837] transition-all duration-300 group-hover:w-full" />
              </a>
            ))}
          </nav>

          {/* Action CTA & Sound Button */}
          <div className="hidden sm:flex items-center space-x-4">
            {/* Studio quick jump */}
            <a
              href="#configurator"
              className="hidden lg:flex items-center space-x-1.5 px-3 py-1.5 rounded-full text-xs font-mono tracking-wider text-zinc-300 border border-white/10 hover:border-white/30 hover:bg-white/5 transition-all"
            >
              <Sparkles className="w-3.5 h-3.5 text-[#E31837]" />
              <span>3D STUDIO</span>
            </a>

            {/* Test Drive Button */}
            <button
              onClick={onOpenTestDrive}
              id="nav-book-test-drive-btn"
              className="relative overflow-hidden px-5 py-2.5 rounded-full bg-[#E31837] text-white text-xs sm:text-sm font-semibold tracking-wider uppercase transition-all duration-300 hover:bg-[#c0132d] hover:shadow-[0_0_25px_rgba(227,24,55,0.6)] active:scale-95 group"
            >
              <span className="relative z-10 flex items-center space-x-1.5">
                <span>BOOK A TEST DRIVE</span>
                <ChevronRight className="w-3.5 h-3.5 transition-transform group-hover:translate-x-0.5" />
              </span>
              <div className="absolute inset-0 -translate-x-full group-hover:translate-x-full transition-transform duration-1000 bg-gradient-to-r from-transparent via-white/20 to-transparent" />
            </button>
          </div>

          {/* Mobile Hamburger Toggle */}
          <div className="flex md:hidden items-center space-x-3">
            <button
              onClick={onOpenTestDrive}
              className="px-3 py-1.5 text-xs font-semibold uppercase tracking-wider bg-[#E31837] text-white rounded-full"
            >
              TEST DRIVE
            </button>
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 text-zinc-300 hover:text-white bg-white/5 border border-white/10 rounded-lg focus:outline-none"
              aria-label="Toggle menu"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>
      </header>

      {/* Mobile Slide-down Drawer */}
      <div
        className={`fixed inset-x-0 top-[65px] z-30 bg-[#0a0a0e]/95 backdrop-blur-2xl border-b border-white/10 transition-all duration-400 ease-in-out md:hidden ${
          mobileMenuOpen ? 'max-h-[400px] opacity-100 py-6' : 'max-h-0 opacity-0 overflow-hidden py-0'
        }`}
      >
        <div className="flex flex-col space-y-4 px-6">
          {navLinks.map((link) => (
            <a
              key={link.name}
              href={link.href}
              onClick={() => setMobileMenuOpen(false)}
              className="text-base font-display font-medium tracking-wider text-zinc-300 hover:text-[#E31837] transition-colors py-1 flex items-center justify-between border-b border-white/5"
            >
              <span>{link.name}</span>
              <ChevronRight className="w-4 h-4 text-zinc-600" />
            </a>
          ))}
          <div className="pt-2 flex flex-col gap-3">
            <a
              href="#configurator"
              onClick={() => setMobileMenuOpen(false)}
              className="w-full py-3 rounded-xl bg-white/5 border border-white/10 text-center font-mono text-xs uppercase tracking-widest text-zinc-200"
            >
              3D Customizer Studio
            </a>
            <button
              onClick={() => {
                setMobileMenuOpen(false);
                onOpenTestDrive();
              }}
              className="w-full py-3.5 rounded-xl bg-[#E31837] text-white font-semibold text-xs uppercase tracking-widest text-center shadow-[0_0_20px_rgba(227,24,55,0.4)]"
            >
              Book A Test Drive
            </button>
          </div>
        </div>
      </div>
    </>
  );
};
