import React, { useState } from 'react';
import { ArrowUp, ChevronRight, Mail, Check } from 'lucide-react';

export const Footer: React.FC = () => {
  const [subscribed, setSubscribed] = useState(false);
  const [email, setEmail] = useState('');

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (email) {
      setSubscribed(true);
      setEmail('');
    }
  };

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="bg-[#030304] text-zinc-400 border-t border-white/10 pt-20 pb-12 overflow-hidden relative">
      {/* Ambient footer glow */}
      <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-[800px] h-[200px] bg-[#E31837]/5 rounded-full blur-[100px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Main Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-12 mb-16">
          {/* Brand Column */}
          <div className="lg:col-span-2 space-y-6">
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 rounded-lg bg-white/5 border border-white/10 flex items-center justify-center">
                <svg className="w-5 h-5 text-white" viewBox="0 0 100 100" fill="none">
                  <path d="M50 15L80 75H65L50 45L35 75H20L50 15Z" fill="#E31837" />
                </svg>
              </div>
              <span className="font-display font-black tracking-[0.25em] text-xl text-white">
                MAHINDRA
              </span>
            </div>

            <p className="text-xs sm:text-sm text-zinc-400 font-light leading-relaxed max-w-sm">
              Pioneering the electric frontier. Born from Indian grit, engineered at Mahindra Advanced Design Europe (M.A.D.E) in Oxfordshire, UK.
            </p>

            {/* Newsletter */}
            <div>
              <span className="text-[11px] font-mono uppercase tracking-widest text-zinc-300 block mb-2 font-semibold">
                STAY INFORMED ON THE NEW ERA
              </span>
              <form onSubmit={handleSubscribe} className="flex max-w-md">
                <input
                  type="email"
                  required
                  placeholder="Enter your corporate or personal email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full bg-white/5 border border-white/10 rounded-l-xl px-4 py-2.5 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-[#E31837]"
                />
                <button
                  type="submit"
                  className="px-5 bg-[#E31837] text-white rounded-r-xl text-xs font-semibold hover:bg-[#c0132d] transition-colors flex items-center justify-center shrink-0"
                >
                  {subscribed ? <Check className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
                </button>
              </form>
              {subscribed && (
                <span className="text-[11px] font-mono text-emerald-400 mt-1.5 block">
                  ✓ You are on the priority dispatch list.
                </span>
              )}
            </div>
          </div>

          {/* Column 2: Electric Fleet */}
          <div>
            <h4 className="text-xs font-mono uppercase tracking-widest text-white font-bold mb-4">
              ELECTRIC LINEUP
            </h4>
            <ul className="space-y-2.5 text-xs">
              <li><a href="#hero" className="hover:text-white transition-colors">Mahindra BE.05 Coupe</a></li>
              <li><a href="#hero" className="hover:text-white transition-colors">Mahindra BE 6e</a></li>
              <li><a href="#hero" className="hover:text-white transition-colors">Mahindra XUV.e9</a></li>
              <li><a href="#hero" className="hover:text-white transition-colors">Mahindra XUV.e8</a></li>
              <li><a href="#hero" className="hover:text-white transition-colors">Mahindra Thar.e</a></li>
            </ul>
          </div>

          {/* Column 3: Architecture & Tech */}
          <div>
            <h4 className="text-xs font-mono uppercase tracking-widest text-white font-bold mb-4">
              INNOVATION
            </h4>
            <ul className="space-y-2.5 text-xs">
              <li><a href="#performance" className="hover:text-white transition-colors">INGLO Skateboard Platform</a></li>
              <li><a href="#performance" className="hover:text-white transition-colors">LFP Blade Battery Safety</a></li>
              <li><a href="#technology" className="hover:text-white transition-colors">Level 2+ ADAS Suite</a></li>
              <li><a href="#technology" className="hover:text-white transition-colors">Snapdragon Digital Chassis</a></li>
              <li><a href="#interior" className="hover:text-white transition-colors">Harman Kardon Spatial Sound</a></li>
            </ul>
          </div>

          {/* Column 4: Ownership & Centers */}
          <div>
            <h4 className="text-xs font-mono uppercase tracking-widest text-white font-bold mb-4">
              OWNERSHIP
            </h4>
            <ul className="space-y-2.5 text-xs">
              <li><a href="#configurator" className="hover:text-white transition-colors">3D Studio Configurator</a></li>
              <li><a href="#hero" className="hover:text-white transition-colors">Find an Experience Center</a></li>
              <li><a href="#hero" className="hover:text-white transition-colors">EV Charging Super-Network</a></li>
              <li><a href="#hero" className="hover:text-white transition-colors">Fleet & Corporate Inquiries</a></li>
              <li><a href="#hero" className="hover:text-white transition-colors">Financial Services & Lease</a></li>
            </ul>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="pt-8 border-t border-white/10 flex flex-col sm:flex-row items-center justify-between text-xs text-zinc-400 gap-4">
          <div className="flex flex-wrap items-center gap-6">
            <span>© {new Date().getFullYear()} Mahindra & Mahindra Ltd. All rights reserved.</span>
            <a href="#" className="hover:text-zinc-300 transition-colors">Privacy Policy</a>
            <a href="#" className="hover:text-zinc-300 transition-colors">Terms of Use</a>
            <a href="#" className="hover:text-zinc-300 transition-colors">Global Disclaimers</a>
          </div>

          <button
            onClick={scrollToTop}
            className="flex items-center space-x-2 px-3 py-1.5 rounded-full bg-white/5 border border-white/10 hover:bg-white/10 text-zinc-300 hover:text-white transition-all text-xs font-mono"
          >
            <span>BACK TO TOP</span>
            <ArrowUp className="w-3.5 h-3.5 text-[#E31837]" />
          </button>
        </div>
      </div>
    </footer>
  );
};
