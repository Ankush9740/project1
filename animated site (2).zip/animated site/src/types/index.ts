export interface DriveMode {
  id: string;
  name: string;
  badge: string;
  tagline: string;
  description: string;
  accentColor: string;
  glowColor: string;
  stats: {
    power: string;
    suspension: string;
    steering: string;
    efficiency: string;
  };
}

export interface ExteriorColor {
  id: string;
  name: string;
  hex: string;
  finish: string;
  description: string;
}

export interface WheelOption {
  id: string;
  name: string;
  size: string;
  design: string;
  efficiencyGain: string;
}

export interface AmbientTheme {
  id: string;
  name: string;
  hex: string;
  glowRgba: string;
  description: string;
}

export interface TestDriveFormData {
  fullName: string;
  email: string;
  phone: string;
  city: string;
  dealership: string;
  model: string;
  preferredDate: string;
  timeSlot: string;
}
