/**
 * Mahindra Frame Preloader
 * High-performance concurrent asset loader with progress tracking
 */

export const TOTAL_FRAMES = 80;

export interface FrameLoadResult {
  images: HTMLImageElement[];
  loadedCount: number;
  totalCount: number;
}

export const preloadFrames = (
  onProgress?: (percent: number, loaded: number, total: number) => void
): Promise<HTMLImageElement[]> => {
  return new Promise((resolve) => {
    const images: HTMLImageElement[] = new Array(TOTAL_FRAMES);
    let loadedCount = 0;

    for (let i = 1; i <= TOTAL_FRAMES; i++) {
      const img = new Image();
      const frameNum = String(i).padStart(3, '0');
      const src = `/frames/frame_${frameNum}.webp`;

      img.onload = () => {
        images[i - 1] = img;
        loadedCount++;
        const percent = Math.round((loadedCount / TOTAL_FRAMES) * 100);
        if (onProgress) {
          onProgress(percent, loadedCount, TOTAL_FRAMES);
        }
        if (loadedCount === TOTAL_FRAMES) {
          resolve(images);
        }
      };

      img.onerror = () => {
        console.warn(`Failed to load frame ${i}, falling back to frame 1`);
        // If an image fails to load, use a dummy or frame 1
        images[i - 1] = images[0] || img;
        loadedCount++;
        const percent = Math.round((loadedCount / TOTAL_FRAMES) * 100);
        if (onProgress) {
          onProgress(percent, loadedCount, TOTAL_FRAMES);
        }
        if (loadedCount === TOTAL_FRAMES) {
          resolve(images);
        }
      };

      img.src = src;
    }
  });
};
